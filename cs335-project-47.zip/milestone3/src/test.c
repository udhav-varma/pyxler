#include<stdio.h>

int main(void)
{
    int x = 4;
    int y = x + 4;
    printf("%d", x);
}