a : int = 10

if a < 20:
    a = 20
else:
    a = a + 15
    
print(a)