Udhav Varma - 33%
Yuvraj Kharayat - 34%
Ashish Meena - 33%