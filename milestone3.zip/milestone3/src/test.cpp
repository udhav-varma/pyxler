#include<bits/stdc++.h>
using namespace std;

int main(void)
{
    int x = 4;
    for(int i=0; i<10; i++){
        x = x + i;
    }

}