/* A Bison parser, made by GNU Bison 3.8.2.  */

/* Bison implementation for Yacc-like parsers in C

   Copyright (C) 1984, 1989-1990, 2000-2015, 2018-2021 Free Software Foundation,
   Inc.

   This program is free software: you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation, either version 3 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program.  If not, see <https://www.gnu.org/licenses/>.  */

/* As a special exception, you may create a larger work that contains
   part or all of the Bison parser skeleton and distribute that work
   under terms of your choice, so long as that work isn't itself a
   parser generator using the skeleton or a modified version thereof
   as a parser skeleton.  Alternatively, if you modify or redistribute
   the parser skeleton itself, you may (at your option) remove this
   special exception, which will cause the skeleton and the resulting
   Bison output files to be licensed under the GNU General Public
   License without this special exception.

   This special exception was added by the Free Software Foundation in
   version 2.2 of Bison.  */

/* C LALR(1) parser skeleton written by Richard Stallman, by
   simplifying the original so-called "semantic" parser.  */

/* DO NOT RELY ON FEATURES THAT ARE NOT DOCUMENTED in the manual,
   especially those whose name start with YY_ or yy_.  They are
   private implementation details that can be changed or removed.  */

/* All symbols defined below should begin with yy or YY, to avoid
   infringing on user name space.  This should be done even for local
   variables, as they might otherwise be expanded by user macros.
   There are some unavoidable exceptions within include files to
   define necessary library symbols; they are noted "INFRINGES ON
   USER NAME SPACE" below.  */

/* Identify Bison output, and Bison version.  */
#define YYBISON 30802

/* Bison version string.  */
#define YYBISON_VERSION "3.8.2"

/* Skeleton name.  */
#define YYSKELETON_NAME "yacc.c"

/* Pure parsers.  */
#define YYPURE 0

/* Push parsers.  */
#define YYPUSH 0

/* Pull parsers.  */
#define YYPULL 1

/* "%code top" blocks.  */
#line 38 "parser.y"

    #include "node.hpp"
    AST ast;
    #define PARSER

#line 74 "parser.tab.cpp"



/* First part of user prologue.  */
#line 11 "parser.y"

    extern int yylex();
    extern int yylineno;
    extern int yydebug;
    extern char * yytext;
    extern FILE * yyin;
    node * root;
    void yyerror(char * s){
    fprintf(stderr, "Error! Line Number %d, token: %s, message: %s\n", yylineno, yytext, s);
    }
    void yyerror(string s){
    fprintf(stderr, "Error! Line Number %d, token: %s, message: %s\n", yylineno, yytext, s.c_str());
    }
    set<string> native_types{"int", "str", "list", "set", "dict"};
    extern stack<int> indents;
    extern vector<string> headers;
    extern symbol_table* present_table;
    #define YYDEBUG 1

#line 99 "parser.tab.cpp"

# ifndef YY_CAST
#  ifdef __cplusplus
#   define YY_CAST(Type, Val) static_cast<Type> (Val)
#   define YY_REINTERPRET_CAST(Type, Val) reinterpret_cast<Type> (Val)
#  else
#   define YY_CAST(Type, Val) ((Type) (Val))
#   define YY_REINTERPRET_CAST(Type, Val) ((Type) (Val))
#  endif
# endif
# ifndef YY_NULLPTR
#  if defined __cplusplus
#   if 201103L <= __cplusplus
#    define YY_NULLPTR nullptr
#   else
#    define YY_NULLPTR 0
#   endif
#  else
#   define YY_NULLPTR ((void*)0)
#  endif
# endif

#include "parser.tab.hpp"
/* Symbol kind.  */
enum yysymbol_kind_t
{
  YYSYMBOL_YYEMPTY = -2,
  YYSYMBOL_YYEOF = 0,                      /* "end of file"  */
  YYSYMBOL_YYerror = 1,                    /* error  */
  YYSYMBOL_YYUNDEF = 2,                    /* "invalid token"  */
  YYSYMBOL_NEWLINE = 3,                    /* NEWLINE  */
  YYSYMBOL_ENDMARKER = 4,                  /* ENDMARKER  */
  YYSYMBOL_ASYNC = 5,                      /* ASYNC  */
  YYSYMBOL_NAME = 6,                       /* NAME  */
  YYSYMBOL_DEL = 7,                        /* DEL  */
  YYSYMBOL_PASS = 8,                       /* PASS  */
  YYSYMBOL_BREAK = 9,                      /* BREAK  */
  YYSYMBOL_CONTINUE = 10,                  /* CONTINUE  */
  YYSYMBOL_RETURN = 11,                    /* RETURN  */
  YYSYMBOL_RAISE = 12,                     /* RAISE  */
  YYSYMBOL_FROM = 13,                      /* FROM  */
  YYSYMBOL_IMPORT = 14,                    /* IMPORT  */
  YYSYMBOL_AS = 15,                        /* AS  */
  YYSYMBOL_GLOBAL = 16,                    /* GLOBAL  */
  YYSYMBOL_NONLOCAL = 17,                  /* NONLOCAL  */
  YYSYMBOL_ASSERT = 18,                    /* ASSERT  */
  YYSYMBOL_IF = 19,                        /* IF  */
  YYSYMBOL_ELIF = 20,                      /* ELIF  */
  YYSYMBOL_ELSE = 21,                      /* ELSE  */
  YYSYMBOL_FOR = 22,                       /* FOR  */
  YYSYMBOL_IN = 23,                        /* IN  */
  YYSYMBOL_WHILE = 24,                     /* WHILE  */
  YYSYMBOL_TRY = 25,                       /* TRY  */
  YYSYMBOL_FINALLY = 26,                   /* FINALLY  */
  YYSYMBOL_WITH = 27,                      /* WITH  */
  YYSYMBOL_EXCEPT = 28,                    /* EXCEPT  */
  YYSYMBOL_LAMBDA = 29,                    /* LAMBDA  */
  YYSYMBOL_NOT = 30,                       /* NOT  */
  YYSYMBOL_OR = 31,                        /* OR  */
  YYSYMBOL_AND = 32,                       /* AND  */
  YYSYMBOL_AWAIT = 33,                     /* AWAIT  */
  YYSYMBOL_IS = 34,                        /* IS  */
  YYSYMBOL_INDENT = 35,                    /* INDENT  */
  YYSYMBOL_DEDENT = 36,                    /* DEDENT  */
  YYSYMBOL_YIELD = 37,                     /* YIELD  */
  YYSYMBOL_TRUE = 38,                      /* TRUE  */
  YYSYMBOL_NUMBER = 39,                    /* NUMBER  */
  YYSYMBOL_STRING = 40,                    /* STRING  */
  YYSYMBOL_FALSE = 41,                     /* FALSE  */
  YYSYMBOL_NONE = 42,                      /* NONE  */
  YYSYMBOL_CLASS = 43,                     /* CLASS  */
  YYSYMBOL_DEF = 44,                       /* DEF  */
  YYSYMBOL_ARROWOP = 45,                   /* ARROWOP  */
  YYSYMBOL_POW = 46,                       /* POW  */
  YYSYMBOL_ADDASSIGN = 47,                 /* ADDASSIGN  */
  YYSYMBOL_SUBASSIGN = 48,                 /* SUBASSIGN  */
  YYSYMBOL_MULASSIGN = 49,                 /* MULASSIGN  */
  YYSYMBOL_ATASSIGN = 50,                  /* ATASSIGN  */
  YYSYMBOL_DIVASSIGN = 51,                 /* DIVASSIGN  */
  YYSYMBOL_MODASSIGN = 52,                 /* MODASSIGN  */
  YYSYMBOL_ANDASSIGN = 53,                 /* ANDASSIGN  */
  YYSYMBOL_ORASSIGN = 54,                  /* ORASSIGN  */
  YYSYMBOL_XORASSIGN = 55,                 /* XORASSIGN  */
  YYSYMBOL_LSASSIGN = 56,                  /* LSASSIGN  */
  YYSYMBOL_RSASSIGN = 57,                  /* RSASSIGN  */
  YYSYMBOL_POWASSIGN = 58,                 /* POWASSIGN  */
  YYSYMBOL_IDIVASSIGN = 59,                /* IDIVASSIGN  */
  YYSYMBOL_ELLIPSIS = 60,                  /* ELLIPSIS  */
  YYSYMBOL_EQUAL = 61,                     /* EQUAL  */
  YYSYMBOL_GEQ = 62,                       /* GEQ  */
  YYSYMBOL_LEQ = 63,                       /* LEQ  */
  YYSYMBOL_LTORGT = 64,                    /* LTORGT  */
  YYSYMBOL_NEQ = 65,                       /* NEQ  */
  YYSYMBOL_LEFTSHIFT = 66,                 /* LEFTSHIFT  */
  YYSYMBOL_RIGHTSHIFT = 67,                /* RIGHTSHIFT  */
  YYSYMBOL_IDIV = 68,                      /* IDIV  */
  YYSYMBOL_69_ = 69,                       /* ':'  */
  YYSYMBOL_70_ = 70,                       /* '('  */
  YYSYMBOL_71_ = 71,                       /* ')'  */
  YYSYMBOL_72_ = 72,                       /* ','  */
  YYSYMBOL_73_ = 73,                       /* ';'  */
  YYSYMBOL_74_ = 74,                       /* '='  */
  YYSYMBOL_75_ = 75,                       /* '<'  */
  YYSYMBOL_76_ = 76,                       /* '>'  */
  YYSYMBOL_77_ = 77,                       /* '|'  */
  YYSYMBOL_78_ = 78,                       /* '^'  */
  YYSYMBOL_79_ = 79,                       /* '&'  */
  YYSYMBOL_80_ = 80,                       /* '+'  */
  YYSYMBOL_81_ = 81,                       /* '-'  */
  YYSYMBOL_82_ = 82,                       /* '*'  */
  YYSYMBOL_83_ = 83,                       /* '@'  */
  YYSYMBOL_84_ = 84,                       /* '/'  */
  YYSYMBOL_85_ = 85,                       /* '%'  */
  YYSYMBOL_86_ = 86,                       /* '~'  */
  YYSYMBOL_87_ = 87,                       /* '['  */
  YYSYMBOL_88_ = 88,                       /* ']'  */
  YYSYMBOL_89_ = 89,                       /* '.'  */
  YYSYMBOL_YYACCEPT = 90,                  /* $accept  */
  YYSYMBOL_file_input = 91,                /* file_input  */
  YYSYMBOL_nstatement = 92,                /* nstatement  */
  YYSYMBOL_cond_arglist = 93,              /* cond_arglist  */
  YYSYMBOL_funcdef = 94,                   /* funcdef  */
  YYSYMBOL_parameters = 95,                /* parameters  */
  YYSYMBOL_cond_typedargslist = 96,        /* cond_typedargslist  */
  YYSYMBOL_typedargslist = 97,             /* typedargslist  */
  YYSYMBOL_tfpdef = 98,                    /* tfpdef  */
  YYSYMBOL_stmt = 99,                      /* stmt  */
  YYSYMBOL_simple_stmt = 100,              /* simple_stmt  */
  YYSYMBOL_small_stmts = 101,              /* small_stmts  */
  YYSYMBOL_cond_semi_colon = 102,          /* cond_semi_colon  */
  YYSYMBOL_small_stmt = 103,               /* small_stmt  */
  YYSYMBOL_expr_stmt = 104,                /* expr_stmt  */
  YYSYMBOL_annassign = 105,                /* annassign  */
  YYSYMBOL_cond_eqtest = 106,              /* cond_eqtest  */
  YYSYMBOL_augassign = 107,                /* augassign  */
  YYSYMBOL_pass_stmt = 108,                /* pass_stmt  */
  YYSYMBOL_flow_stmt = 109,                /* flow_stmt  */
  YYSYMBOL_break_stmt = 110,               /* break_stmt  */
  YYSYMBOL_continue_stmt = 111,            /* continue_stmt  */
  YYSYMBOL_return_stmt = 112,              /* return_stmt  */
  YYSYMBOL_global_stmt = 113,              /* global_stmt  */
  YYSYMBOL_namelist = 114,                 /* namelist  */
  YYSYMBOL_compound_stmt = 115,            /* compound_stmt  */
  YYSYMBOL_if_stmt = 116,                  /* if_stmt  */
  YYSYMBOL_cond_else_colon_suite = 117,    /* cond_else_colon_suite  */
  YYSYMBOL_close_eliftestsuite = 118,      /* close_eliftestsuite  */
  YYSYMBOL_while_stmt = 119,               /* while_stmt  */
  YYSYMBOL_for_stmt = 120,                 /* for_stmt  */
  YYSYMBOL_suite = 121,                    /* suite  */
  YYSYMBOL_plus_stmt = 122,                /* plus_stmt  */
  YYSYMBOL_test = 123,                     /* test  */
  YYSYMBOL_or_test = 124,                  /* or_test  */
  YYSYMBOL_and_test = 125,                 /* and_test  */
  YYSYMBOL_not_test = 126,                 /* not_test  */
  YYSYMBOL_comparison = 127,               /* comparison  */
  YYSYMBOL_comp_op = 128,                  /* comp_op  */
  YYSYMBOL_expr = 129,                     /* expr  */
  YYSYMBOL_xor_expr = 130,                 /* xor_expr  */
  YYSYMBOL_and_expr = 131,                 /* and_expr  */
  YYSYMBOL_shift_expr = 132,               /* shift_expr  */
  YYSYMBOL_arith_expr = 133,               /* arith_expr  */
  YYSYMBOL_term = 134,                     /* term  */
  YYSYMBOL_muldivremops = 135,             /* muldivremops  */
  YYSYMBOL_factor = 136,                   /* factor  */
  YYSYMBOL_plus_or_minus_or_not = 137,     /* plus_or_minus_or_not  */
  YYSYMBOL_power = 138,                    /* power  */
  YYSYMBOL_atom_expr = 139,                /* atom_expr  */
  YYSYMBOL_atom = 140,                     /* atom  */
  YYSYMBOL_testlist = 141,                 /* testlist  */
  YYSYMBOL_trailer = 142,                  /* trailer  */
  YYSYMBOL_classdef = 143,                 /* classdef  */
  YYSYMBOL_cond_parent_class = 144,        /* cond_parent_class  */
  YYSYMBOL_arglist = 145,                  /* arglist  */
  YYSYMBOL_argument = 146                  /* argument  */
};
typedef enum yysymbol_kind_t yysymbol_kind_t;




#ifdef short
# undef short
#endif

/* On compilers that do not define __PTRDIFF_MAX__ etc., make sure
   <limits.h> and (if available) <stdint.h> are included
   so that the code can choose integer types of a good width.  */

#ifndef __PTRDIFF_MAX__
# include <limits.h> /* INFRINGES ON USER NAME SPACE */
# if defined __STDC_VERSION__ && 199901 <= __STDC_VERSION__
#  include <stdint.h> /* INFRINGES ON USER NAME SPACE */
#  define YY_STDINT_H
# endif
#endif

/* Narrow types that promote to a signed type and that can represent a
   signed or unsigned integer of at least N bits.  In tables they can
   save space and decrease cache pressure.  Promoting to a signed type
   helps avoid bugs in integer arithmetic.  */

#ifdef __INT_LEAST8_MAX__
typedef __INT_LEAST8_TYPE__ yytype_int8;
#elif defined YY_STDINT_H
typedef int_least8_t yytype_int8;
#else
typedef signed char yytype_int8;
#endif

#ifdef __INT_LEAST16_MAX__
typedef __INT_LEAST16_TYPE__ yytype_int16;
#elif defined YY_STDINT_H
typedef int_least16_t yytype_int16;
#else
typedef short yytype_int16;
#endif

/* Work around bug in HP-UX 11.23, which defines these macros
   incorrectly for preprocessor constants.  This workaround can likely
   be removed in 2023, as HPE has promised support for HP-UX 11.23
   (aka HP-UX 11i v2) only through the end of 2022; see Table 2 of
   <https://h20195.www2.hpe.com/V2/getpdf.aspx/4AA4-7673ENW.pdf>.  */
#ifdef __hpux
# undef UINT_LEAST8_MAX
# undef UINT_LEAST16_MAX
# define UINT_LEAST8_MAX 255
# define UINT_LEAST16_MAX 65535
#endif

#if defined __UINT_LEAST8_MAX__ && __UINT_LEAST8_MAX__ <= __INT_MAX__
typedef __UINT_LEAST8_TYPE__ yytype_uint8;
#elif (!defined __UINT_LEAST8_MAX__ && defined YY_STDINT_H \
       && UINT_LEAST8_MAX <= INT_MAX)
typedef uint_least8_t yytype_uint8;
#elif !defined __UINT_LEAST8_MAX__ && UCHAR_MAX <= INT_MAX
typedef unsigned char yytype_uint8;
#else
typedef short yytype_uint8;
#endif

#if defined __UINT_LEAST16_MAX__ && __UINT_LEAST16_MAX__ <= __INT_MAX__
typedef __UINT_LEAST16_TYPE__ yytype_uint16;
#elif (!defined __UINT_LEAST16_MAX__ && defined YY_STDINT_H \
       && UINT_LEAST16_MAX <= INT_MAX)
typedef uint_least16_t yytype_uint16;
#elif !defined __UINT_LEAST16_MAX__ && USHRT_MAX <= INT_MAX
typedef unsigned short yytype_uint16;
#else
typedef int yytype_uint16;
#endif

#ifndef YYPTRDIFF_T
# if defined __PTRDIFF_TYPE__ && defined __PTRDIFF_MAX__
#  define YYPTRDIFF_T __PTRDIFF_TYPE__
#  define YYPTRDIFF_MAXIMUM __PTRDIFF_MAX__
# elif defined PTRDIFF_MAX
#  ifndef ptrdiff_t
#   include <stddef.h> /* INFRINGES ON USER NAME SPACE */
#  endif
#  define YYPTRDIFF_T ptrdiff_t
#  define YYPTRDIFF_MAXIMUM PTRDIFF_MAX
# else
#  define YYPTRDIFF_T long
#  define YYPTRDIFF_MAXIMUM LONG_MAX
# endif
#endif

#ifndef YYSIZE_T
# ifdef __SIZE_TYPE__
#  define YYSIZE_T __SIZE_TYPE__
# elif defined size_t
#  define YYSIZE_T size_t
# elif defined __STDC_VERSION__ && 199901 <= __STDC_VERSION__
#  include <stddef.h> /* INFRINGES ON USER NAME SPACE */
#  define YYSIZE_T size_t
# else
#  define YYSIZE_T unsigned
# endif
#endif

#define YYSIZE_MAXIMUM                                  \
  YY_CAST (YYPTRDIFF_T,                                 \
           (YYPTRDIFF_MAXIMUM < YY_CAST (YYSIZE_T, -1)  \
            ? YYPTRDIFF_MAXIMUM                         \
            : YY_CAST (YYSIZE_T, -1)))

#define YYSIZEOF(X) YY_CAST (YYPTRDIFF_T, sizeof (X))


/* Stored state numbers (used for stacks). */
typedef yytype_uint8 yy_state_t;

/* State numbers in computations.  */
typedef int yy_state_fast_t;

#ifndef YY_
# if defined YYENABLE_NLS && YYENABLE_NLS
#  if ENABLE_NLS
#   include <libintl.h> /* INFRINGES ON USER NAME SPACE */
#   define YY_(Msgid) dgettext ("bison-runtime", Msgid)
#  endif
# endif
# ifndef YY_
#  define YY_(Msgid) Msgid
# endif
#endif


#ifndef YY_ATTRIBUTE_PURE
# if defined __GNUC__ && 2 < __GNUC__ + (96 <= __GNUC_MINOR__)
#  define YY_ATTRIBUTE_PURE __attribute__ ((__pure__))
# else
#  define YY_ATTRIBUTE_PURE
# endif
#endif

#ifndef YY_ATTRIBUTE_UNUSED
# if defined __GNUC__ && 2 < __GNUC__ + (7 <= __GNUC_MINOR__)
#  define YY_ATTRIBUTE_UNUSED __attribute__ ((__unused__))
# else
#  define YY_ATTRIBUTE_UNUSED
# endif
#endif

/* Suppress unused-variable warnings by "using" E.  */
#if ! defined lint || defined __GNUC__
# define YY_USE(E) ((void) (E))
#else
# define YY_USE(E) /* empty */
#endif

/* Suppress an incorrect diagnostic about yylval being uninitialized.  */
#if defined __GNUC__ && ! defined __ICC && 406 <= __GNUC__ * 100 + __GNUC_MINOR__
# if __GNUC__ * 100 + __GNUC_MINOR__ < 407
#  define YY_IGNORE_MAYBE_UNINITIALIZED_BEGIN                           \
    _Pragma ("GCC diagnostic push")                                     \
    _Pragma ("GCC diagnostic ignored \"-Wuninitialized\"")
# else
#  define YY_IGNORE_MAYBE_UNINITIALIZED_BEGIN                           \
    _Pragma ("GCC diagnostic push")                                     \
    _Pragma ("GCC diagnostic ignored \"-Wuninitialized\"")              \
    _Pragma ("GCC diagnostic ignored \"-Wmaybe-uninitialized\"")
# endif
# define YY_IGNORE_MAYBE_UNINITIALIZED_END      \
    _Pragma ("GCC diagnostic pop")
#else
# define YY_INITIAL_VALUE(Value) Value
#endif
#ifndef YY_IGNORE_MAYBE_UNINITIALIZED_BEGIN
# define YY_IGNORE_MAYBE_UNINITIALIZED_BEGIN
# define YY_IGNORE_MAYBE_UNINITIALIZED_END
#endif
#ifndef YY_INITIAL_VALUE
# define YY_INITIAL_VALUE(Value) /* Nothing. */
#endif

#if defined __cplusplus && defined __GNUC__ && ! defined __ICC && 6 <= __GNUC__
# define YY_IGNORE_USELESS_CAST_BEGIN                          \
    _Pragma ("GCC diagnostic push")                            \
    _Pragma ("GCC diagnostic ignored \"-Wuseless-cast\"")
# define YY_IGNORE_USELESS_CAST_END            \
    _Pragma ("GCC diagnostic pop")
#endif
#ifndef YY_IGNORE_USELESS_CAST_BEGIN
# define YY_IGNORE_USELESS_CAST_BEGIN
# define YY_IGNORE_USELESS_CAST_END
#endif


#define YY_ASSERT(E) ((void) (0 && (E)))

#if !defined yyoverflow

/* The parser invokes alloca or malloc; define the necessary symbols.  */

# ifdef YYSTACK_USE_ALLOCA
#  if YYSTACK_USE_ALLOCA
#   ifdef __GNUC__
#    define YYSTACK_ALLOC __builtin_alloca
#   elif defined __BUILTIN_VA_ARG_INCR
#    include <alloca.h> /* INFRINGES ON USER NAME SPACE */
#   elif defined _AIX
#    define YYSTACK_ALLOC __alloca
#   elif defined _MSC_VER
#    include <malloc.h> /* INFRINGES ON USER NAME SPACE */
#    define alloca _alloca
#   else
#    define YYSTACK_ALLOC alloca
#    if ! defined _ALLOCA_H && ! defined EXIT_SUCCESS
#     include <stdlib.h> /* INFRINGES ON USER NAME SPACE */
      /* Use EXIT_SUCCESS as a witness for stdlib.h.  */
#     ifndef EXIT_SUCCESS
#      define EXIT_SUCCESS 0
#     endif
#    endif
#   endif
#  endif
# endif

# ifdef YYSTACK_ALLOC
   /* Pacify GCC's 'empty if-body' warning.  */
#  define YYSTACK_FREE(Ptr) do { /* empty */; } while (0)
#  ifndef YYSTACK_ALLOC_MAXIMUM
    /* The OS might guarantee only one guard page at the bottom of the stack,
       and a page size can be as small as 4096 bytes.  So we cannot safely
       invoke alloca (N) if N exceeds 4096.  Use a slightly smaller number
       to allow for a few compiler-allocated temporary stack slots.  */
#   define YYSTACK_ALLOC_MAXIMUM 4032 /* reasonable circa 2006 */
#  endif
# else
#  define YYSTACK_ALLOC YYMALLOC
#  define YYSTACK_FREE YYFREE
#  ifndef YYSTACK_ALLOC_MAXIMUM
#   define YYSTACK_ALLOC_MAXIMUM YYSIZE_MAXIMUM
#  endif
#  if (defined __cplusplus && ! defined EXIT_SUCCESS \
       && ! ((defined YYMALLOC || defined malloc) \
             && (defined YYFREE || defined free)))
#   include <stdlib.h> /* INFRINGES ON USER NAME SPACE */
#   ifndef EXIT_SUCCESS
#    define EXIT_SUCCESS 0
#   endif
#  endif
#  ifndef YYMALLOC
#   define YYMALLOC malloc
#   if ! defined malloc && ! defined EXIT_SUCCESS
void *malloc (YYSIZE_T); /* INFRINGES ON USER NAME SPACE */
#   endif
#  endif
#  ifndef YYFREE
#   define YYFREE free
#   if ! defined free && ! defined EXIT_SUCCESS
void free (void *); /* INFRINGES ON USER NAME SPACE */
#   endif
#  endif
# endif
#endif /* !defined yyoverflow */

#if (! defined yyoverflow \
     && (! defined __cplusplus \
         || (defined YYSTYPE_IS_TRIVIAL && YYSTYPE_IS_TRIVIAL)))

/* A type that is properly aligned for any stack member.  */
union yyalloc
{
  yy_state_t yyss_alloc;
  YYSTYPE yyvs_alloc;
};

/* The size of the maximum gap between one aligned stack and the next.  */
# define YYSTACK_GAP_MAXIMUM (YYSIZEOF (union yyalloc) - 1)

/* The size of an array large to enough to hold all stacks, each with
   N elements.  */
# define YYSTACK_BYTES(N) \
     ((N) * (YYSIZEOF (yy_state_t) + YYSIZEOF (YYSTYPE)) \
      + YYSTACK_GAP_MAXIMUM)

# define YYCOPY_NEEDED 1

/* Relocate STACK from its old location to the new one.  The
   local variables YYSIZE and YYSTACKSIZE give the old and new number of
   elements in the stack, and YYPTR gives the new location of the
   stack.  Advance YYPTR to a properly aligned location for the next
   stack.  */
# define YYSTACK_RELOCATE(Stack_alloc, Stack)                           \
    do                                                                  \
      {                                                                 \
        YYPTRDIFF_T yynewbytes;                                         \
        YYCOPY (&yyptr->Stack_alloc, Stack, yysize);                    \
        Stack = &yyptr->Stack_alloc;                                    \
        yynewbytes = yystacksize * YYSIZEOF (*Stack) + YYSTACK_GAP_MAXIMUM; \
        yyptr += yynewbytes / YYSIZEOF (*yyptr);                        \
      }                                                                 \
    while (0)

#endif

#if defined YYCOPY_NEEDED && YYCOPY_NEEDED
/* Copy COUNT objects from SRC to DST.  The source and destination do
   not overlap.  */
# ifndef YYCOPY
#  if defined __GNUC__ && 1 < __GNUC__
#   define YYCOPY(Dst, Src, Count) \
      __builtin_memcpy (Dst, Src, YY_CAST (YYSIZE_T, (Count)) * sizeof (*(Src)))
#  else
#   define YYCOPY(Dst, Src, Count)              \
      do                                        \
        {                                       \
          YYPTRDIFF_T yyi;                      \
          for (yyi = 0; yyi < (Count); yyi++)   \
            (Dst)[yyi] = (Src)[yyi];            \
        }                                       \
      while (0)
#  endif
# endif
#endif /* !YYCOPY_NEEDED */

/* YYFINAL -- State number of the termination state.  */
#define YYFINAL  3
/* YYLAST -- Last index in YYTABLE.  */
#define YYLAST   383

/* YYNTOKENS -- Number of terminals.  */
#define YYNTOKENS  90
/* YYNNTS -- Number of nonterminals.  */
#define YYNNTS  57
/* YYNRULES -- Number of rules.  */
#define YYNRULES  142
/* YYNSTATES -- Number of states.  */
#define YYNSTATES  212

/* YYMAXUTOK -- Last valid token kind.  */
#define YYMAXUTOK   323


/* YYTRANSLATE(TOKEN-NUM) -- Symbol number corresponding to TOKEN-NUM
   as returned by yylex, with out-of-bounds checking.  */
#define YYTRANSLATE(YYX)                                \
  (0 <= (YYX) && (YYX) <= YYMAXUTOK                     \
   ? YY_CAST (yysymbol_kind_t, yytranslate[YYX])        \
   : YYSYMBOL_YYUNDEF)

/* YYTRANSLATE[TOKEN-NUM] -- Symbol number corresponding to TOKEN-NUM
   as returned by yylex.  */
static const yytype_int8 yytranslate[] =
{
       0,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,    85,    79,     2,
      70,    71,    82,    80,    72,    81,    89,    84,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,    69,    73,
      75,    74,    76,     2,    83,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,    87,     2,    88,    78,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,    77,     2,    86,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     1,     2,     3,     4,
       5,     6,     7,     8,     9,    10,    11,    12,    13,    14,
      15,    16,    17,    18,    19,    20,    21,    22,    23,    24,
      25,    26,    27,    28,    29,    30,    31,    32,    33,    34,
      35,    36,    37,    38,    39,    40,    41,    42,    43,    44,
      45,    46,    47,    48,    49,    50,    51,    52,    53,    54,
      55,    56,    57,    58,    59,    60,    61,    62,    63,    64,
      65,    66,    67,    68
};

#if YYDEBUG
/* YYRLINE[YYN] -- Source line where rule number YYN was defined.  */
static const yytype_int16 yyrline[] =
{
       0,   114,   114,   124,   129,   134,   137,   140,   143,   157,
     164,   166,   170,   175,   183,   192,   194,   197,   204,   206,
     212,   215,   218,   221,   224,   227,   230,   235,   241,   247,
     251,   257,   262,   268,   273,   276,   279,   282,   285,   288,
     291,   294,   297,   300,   303,   306,   309,   312,   315,   318,
     321,   325,   331,   337,   342,   348,   354,   356,   364,   366,
     368,   370,   373,   377,   387,   392,   396,   403,   407,   414,
     424,   426,   433,   435,   441,   447,   451,   458,   462,   469,
     473,   479,   483,   495,   497,   499,   501,   503,   505,   507,
     509,   511,   516,   518,   526,   531,   538,   542,   549,   553,
     561,   565,   570,   580,   582,   587,   595,   600,   608,   610,
     612,   614,   616,   620,   625,   634,   636,   638,   642,   647,
     653,   657,   662,   669,   675,   680,   685,   688,   691,   694,
     697,   700,   705,   708,   715,   721,   727,   736,   745,   750,
     754,   757,   775
};
#endif

/** Accessing symbol of state STATE.  */
#define YY_ACCESSING_SYMBOL(State) YY_CAST (yysymbol_kind_t, yystos[State])

#if YYDEBUG || 0
/* The user-facing name of the symbol whose (internal) number is
   YYSYMBOL.  No bounds checking.  */
static const char *yysymbol_name (yysymbol_kind_t yysymbol) YY_ATTRIBUTE_UNUSED;

/* YYTNAME[SYMBOL-NUM] -- String name of the symbol SYMBOL-NUM.
   First, the terminals, then, starting at YYNTOKENS, nonterminals.  */
static const char *const yytname[] =
{
  "\"end of file\"", "error", "\"invalid token\"", "NEWLINE", "ENDMARKER",
  "ASYNC", "NAME", "DEL", "PASS", "BREAK", "CONTINUE", "RETURN", "RAISE",
  "FROM", "IMPORT", "AS", "GLOBAL", "NONLOCAL", "ASSERT", "IF", "ELIF",
  "ELSE", "FOR", "IN", "WHILE", "TRY", "FINALLY", "WITH", "EXCEPT",
  "LAMBDA", "NOT", "OR", "AND", "AWAIT", "IS", "INDENT", "DEDENT", "YIELD",
  "TRUE", "NUMBER", "STRING", "FALSE", "NONE", "CLASS", "DEF", "ARROWOP",
  "POW", "ADDASSIGN", "SUBASSIGN", "MULASSIGN", "ATASSIGN", "DIVASSIGN",
  "MODASSIGN", "ANDASSIGN", "ORASSIGN", "XORASSIGN", "LSASSIGN",
  "RSASSIGN", "POWASSIGN", "IDIVASSIGN", "ELLIPSIS", "EQUAL", "GEQ", "LEQ",
  "LTORGT", "NEQ", "LEFTSHIFT", "RIGHTSHIFT", "IDIV", "':'", "'('", "')'",
  "','", "';'", "'='", "'<'", "'>'", "'|'", "'^'", "'&'", "'+'", "'-'",
  "'*'", "'@'", "'/'", "'%'", "'~'", "'['", "']'", "'.'", "$accept",
  "file_input", "nstatement", "cond_arglist", "funcdef", "parameters",
  "cond_typedargslist", "typedargslist", "tfpdef", "stmt", "simple_stmt",
  "small_stmts", "cond_semi_colon", "small_stmt", "expr_stmt", "annassign",
  "cond_eqtest", "augassign", "pass_stmt", "flow_stmt", "break_stmt",
  "continue_stmt", "return_stmt", "global_stmt", "namelist",
  "compound_stmt", "if_stmt", "cond_else_colon_suite",
  "close_eliftestsuite", "while_stmt", "for_stmt", "suite", "plus_stmt",
  "test", "or_test", "and_test", "not_test", "comparison", "comp_op",
  "expr", "xor_expr", "and_expr", "shift_expr", "arith_expr", "term",
  "muldivremops", "factor", "plus_or_minus_or_not", "power", "atom_expr",
  "atom", "testlist", "trailer", "classdef", "cond_parent_class",
  "arglist", "argument", YY_NULLPTR
};

static const char *
yysymbol_name (yysymbol_kind_t yysymbol)
{
  return yytname[yysymbol];
}
#endif

#define YYPACT_NINF (-165)

#define yypact_value_is_default(Yyn) \
  ((Yyn) == YYPACT_NINF)

#define YYTABLE_NINF (-1)

#define yytable_value_is_error(Yyn) \
  0

/* YYPACT[STATE-NUM] -- Index in YYTABLE of the portion describing
   STATE-NUM.  */
static const yytype_int16 yypact[] =
{
    -165,    12,    16,  -165,  -165,  -165,  -165,  -165,  -165,  -165,
     246,     9,   246,    11,   246,   246,  -165,  -165,  -165,  -165,
    -165,    25,    33,   246,  -165,  -165,  -165,    94,  -165,  -165,
    -165,   -32,  -165,  -165,  -165,  -165,  -165,  -165,  -165,  -165,
    -165,  -165,  -165,  -165,   177,    18,    19,  -165,    65,   -27,
     -25,   -18,   -60,   -71,   -40,  -165,   296,  -165,    17,   -66,
    -165,  -165,  -165,   -10,    -1,    44,     0,  -165,     2,     3,
       4,  -165,  -165,   -59,   283,    67,  -165,  -165,  -165,  -165,
    -165,  -165,  -165,  -165,  -165,  -165,  -165,  -165,  -165,   246,
     246,  -165,   246,   246,   246,  -165,    59,    60,  -165,  -165,
    -165,  -165,  -165,  -165,  -165,   296,   296,   296,   296,   296,
     296,   296,   296,  -165,  -165,  -165,  -165,  -165,   296,  -165,
     296,   246,   246,    85,   -66,    87,    68,   246,    68,    88,
      32,    98,    66,  -165,   246,  -165,  -165,  -165,    31,  -165,
    -165,    19,  -165,  -165,  -165,   -27,   -25,   -18,   -60,   -71,
     -71,   -40,   -40,  -165,  -165,    43,  -165,    45,  -165,    27,
    -165,  -165,  -165,    81,  -165,  -165,    50,  -165,    49,    68,
      52,    51,    70,    57,   246,  -165,   246,  -165,   246,  -165,
     231,    13,    68,  -165,  -165,   246,  -165,    98,   246,  -165,
      54,  -165,  -165,  -165,   179,   246,    74,  -165,  -165,  -165,
      57,  -165,    68,  -165,  -165,    75,    68,  -165,  -165,    68,
    -165,  -165
};

/* YYDEFACT[STATE-NUM] -- Default reduction number in state STATE-NUM.
   Performed when YYTABLE does not specify something else to do.  Zero
   means the default is an error.  */
static const yytype_uint8 yydefact[] =
{
       5,     0,     0,     1,     3,     2,   126,    47,    51,    52,
      54,     0,     0,     0,     0,     0,   129,   127,   131,   130,
     128,     0,     0,     0,   115,   116,   117,     0,    61,     4,
      15,    21,    18,    22,    23,    24,    48,    49,    50,    25,
      16,    58,    59,    60,    29,    74,    75,    77,    80,    81,
      94,    96,    98,   100,   103,   106,     0,   114,   119,   120,
      62,    53,    56,    55,     0,     0,     0,    79,   139,     0,
       0,   124,   132,     0,    20,     0,    34,    35,    36,    37,
      38,    39,    40,    41,    42,    43,    44,    45,    46,     0,
       0,    26,     0,     0,     0,    90,     0,    92,    85,    86,
      87,    88,    89,    83,    84,     0,     0,     0,     0,     0,
       0,     0,     0,   112,   108,   109,   110,   111,     0,   113,
       0,     7,     0,     0,   121,     0,     0,     0,     0,     0,
       0,    11,     0,   125,     0,   123,    19,    17,    31,    28,
      27,    76,    78,    91,    93,    82,    95,    97,    99,   101,
     102,   104,   105,   107,   118,     0,   142,     6,   140,     0,
     136,   122,    57,     0,    70,    67,     0,    68,     0,     0,
       0,     0,    10,    33,     0,   133,     0,   134,     0,   135,
       0,    65,     0,   138,   137,     0,     9,     0,     0,    12,
       0,    30,   141,    72,     0,     0,     0,    63,    69,    14,
      33,    32,     0,    71,    73,     0,     0,    13,     8,     0,
      64,    66
};

/* YYPGOTO[NTERM-NUM].  */
static const yytype_int16 yypgoto[] =
{
    -165,  -165,  -165,  -165,  -165,  -165,  -165,  -165,   -50,  -164,
      -2,  -165,  -165,    71,  -165,  -165,   -61,  -165,  -165,  -165,
    -165,  -165,  -165,  -165,  -165,  -165,  -165,  -165,  -165,  -165,
    -165,  -117,  -165,    -9,  -165,    53,    -7,  -165,  -165,    42,
      46,    55,    48,   -73,   -64,  -165,   -54,  -165,  -165,  -165,
    -165,  -165,    26,  -165,  -165,  -165,   -21
};

/* YYDEFGOTO[NTERM-NUM].  */
static const yytype_uint8 yydefgoto[] =
{
       0,     1,     2,   155,    28,   132,   171,   172,   173,    29,
     164,    31,    75,    32,    33,    91,   189,    92,    34,    35,
      36,    37,    38,    39,    63,    40,    41,   197,   181,    42,
      43,   165,   194,    44,    45,    46,    47,    48,   105,    49,
      50,    51,    52,    53,    54,   118,    55,    56,    57,    58,
      59,    73,   124,    60,   130,   157,   158
};

/* YYTABLE[YYPACT[STATE-NUM]] -- What to do in state STATE-NUM.  If
   positive, shift that token.  If negative, reduce the rule whose
   number is the opposite.  If YYTABLE_NINF, syntax error.  */
static const yytype_uint8 yytable[] =
{
      30,    61,   119,    64,   121,    66,   109,   110,    67,   111,
     112,   167,     3,   134,    70,    62,   193,    65,    72,     4,
       5,   122,     6,   123,     7,     8,     9,    10,   113,   135,
     204,    68,    11,   195,   196,    12,   149,   150,    13,    69,
      14,    74,   114,   115,   116,   117,    15,   151,   152,    93,
     106,    94,   184,   107,    16,    17,    18,    19,    20,    21,
      22,   108,   125,   120,   153,   198,   154,   127,   126,   128,
     137,   163,   129,   131,     6,   133,     7,     8,     9,    10,
     138,   139,   143,   140,    11,   208,    23,   142,    95,   210,
     144,   160,   211,   162,   168,    96,    24,    25,    15,    97,
       6,   169,    26,    27,   170,   176,    16,    17,    18,    19,
      20,   174,   156,   159,   177,   179,   180,   178,   166,   182,
     183,   185,   186,   202,    15,   175,    98,    99,   100,   101,
     102,   188,    16,    17,    18,    19,    20,   200,    23,   207,
     103,   104,   187,   206,   209,   136,   141,   145,    24,    25,
     161,     0,   146,     0,    26,    27,   148,   192,     0,     0,
       0,     0,   147,     0,    23,   190,     0,   191,     0,   156,
       0,     0,     0,     0,    24,    25,   199,     0,    30,   201,
      26,    27,    71,     0,     0,     6,   205,     7,     8,     9,
      10,     0,    30,     0,     0,    11,     0,     0,    12,     0,
       0,    13,     0,    14,     0,     0,     0,     0,     0,    15,
       0,     0,     0,     0,     0,   203,     0,    16,    17,    18,
      19,    20,    21,    22,    76,    77,    78,    79,    80,    81,
      82,    83,    84,    85,    86,    87,    88,     6,     0,     7,
       8,     9,    10,     0,     0,     0,    89,    11,     0,    23,
      12,    90,     6,    13,     0,    14,     0,     0,     0,    24,
      25,    15,     0,     0,     0,    26,    27,     0,     0,    16,
      17,    18,    19,    20,    21,    22,    15,     0,     0,     0,
       0,     0,     0,     0,    16,    17,    18,    19,    20,     6,
       0,     7,     8,     9,    10,     0,     0,     0,     0,    11,
       0,    23,     6,     0,     0,     0,     0,     0,     0,     0,
       0,    24,    25,    15,     0,     0,    23,    26,    27,     0,
       0,    16,    17,    18,    19,    20,    24,    25,     0,     0,
       0,     0,    26,    27,    16,    17,    18,    19,    20,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,    23,     0,     0,     0,     0,     0,     0,
       0,     0,     0,    24,    25,     0,    23,     0,     0,    26,
      27,     0,     0,     0,     0,     0,    24,    25,     0,     0,
       0,     0,    26,    27
};

static const yytype_int16 yycheck[] =
{
       2,    10,    56,    12,    70,    14,    66,    67,    15,    80,
      81,   128,     0,    72,    23,     6,   180,     6,    27,     3,
       4,    87,     6,    89,     8,     9,    10,    11,    68,    88,
     194,     6,    16,    20,    21,    19,   109,   110,    22,     6,
      24,    73,    82,    83,    84,    85,    30,   111,   112,    31,
      77,    32,   169,    78,    38,    39,    40,    41,    42,    43,
      44,    79,    72,    46,   118,   182,   120,    23,    69,    69,
       3,     3,    70,    70,     6,    71,     8,     9,    10,    11,
      89,    90,    23,    92,    16,   202,    70,    94,    23,   206,
      30,     6,   209,     6,     6,    30,    80,    81,    30,    34,
       6,    69,    86,    87,     6,    74,    38,    39,    40,    41,
      42,    45,   121,   122,    71,    88,    35,    72,   127,    69,
      71,    69,    71,    69,    30,   134,    61,    62,    63,    64,
      65,    74,    38,    39,    40,    41,    42,   187,    70,   200,
      75,    76,    72,    69,    69,    74,    93,   105,    80,    81,
     124,    -1,   106,    -1,    86,    87,   108,   178,    -1,    -1,
      -1,    -1,   107,    -1,    70,   174,    -1,   176,    -1,   178,
      -1,    -1,    -1,    -1,    80,    81,   185,    -1,   180,   188,
      86,    87,    88,    -1,    -1,     6,   195,     8,     9,    10,
      11,    -1,   194,    -1,    -1,    16,    -1,    -1,    19,    -1,
      -1,    22,    -1,    24,    -1,    -1,    -1,    -1,    -1,    30,
      -1,    -1,    -1,    -1,    -1,    36,    -1,    38,    39,    40,
      41,    42,    43,    44,    47,    48,    49,    50,    51,    52,
      53,    54,    55,    56,    57,    58,    59,     6,    -1,     8,
       9,    10,    11,    -1,    -1,    -1,    69,    16,    -1,    70,
      19,    74,     6,    22,    -1,    24,    -1,    -1,    -1,    80,
      81,    30,    -1,    -1,    -1,    86,    87,    -1,    -1,    38,
      39,    40,    41,    42,    43,    44,    30,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    38,    39,    40,    41,    42,     6,
      -1,     8,     9,    10,    11,    -1,    -1,    -1,    -1,    16,
      -1,    70,     6,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    80,    81,    30,    -1,    -1,    70,    86,    87,    -1,
      -1,    38,    39,    40,    41,    42,    80,    81,    -1,    -1,
      -1,    -1,    86,    87,    38,    39,    40,    41,    42,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    70,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    80,    81,    -1,    70,    -1,    -1,    86,
      87,    -1,    -1,    -1,    -1,    -1,    80,    81,    -1,    -1,
      -1,    -1,    86,    87
};

/* YYSTOS[STATE-NUM] -- The symbol kind of the accessing symbol of
   state STATE-NUM.  */
static const yytype_uint8 yystos[] =
{
       0,    91,    92,     0,     3,     4,     6,     8,     9,    10,
      11,    16,    19,    22,    24,    30,    38,    39,    40,    41,
      42,    43,    44,    70,    80,    81,    86,    87,    94,    99,
     100,   101,   103,   104,   108,   109,   110,   111,   112,   113,
     115,   116,   119,   120,   123,   124,   125,   126,   127,   129,
     130,   131,   132,   133,   134,   136,   137,   138,   139,   140,
     143,   123,     6,   114,   123,     6,   123,   126,     6,     6,
     123,    88,   123,   141,    73,   102,    47,    48,    49,    50,
      51,    52,    53,    54,    55,    56,    57,    58,    59,    69,
      74,   105,   107,    31,    32,    23,    30,    34,    61,    62,
      63,    64,    65,    75,    76,   128,    77,    78,    79,    66,
      67,    80,    81,    68,    82,    83,    84,    85,   135,   136,
      46,    70,    87,    89,   142,    72,    69,    23,    69,    70,
     144,    70,    95,    71,    72,    88,   103,     3,   123,   123,
     123,   125,   126,    23,    30,   129,   130,   131,   132,   133,
     133,   134,   134,   136,   136,    93,   123,   145,   146,   123,
       6,   142,     6,     3,   100,   121,   123,   121,     6,    69,
       6,    96,    97,    98,    45,   123,    74,    71,    72,    88,
      35,   118,    69,    71,   121,    69,    71,    72,    74,   106,
     123,   123,   146,    99,   122,    20,    21,   117,   121,   123,
      98,   123,    69,    36,    99,   123,    69,   106,   121,    69,
     121,   121
};

/* YYR1[RULE-NUM] -- Symbol kind of the left-hand side of rule RULE-NUM.  */
static const yytype_uint8 yyr1[] =
{
       0,    90,    91,    92,    92,    92,    93,    93,    94,    95,
      96,    96,    97,    97,    98,    99,    99,   100,   101,   101,
     102,   102,   103,   103,   103,   103,   104,   104,   104,   104,
     105,   105,   106,   106,   107,   107,   107,   107,   107,   107,
     107,   107,   107,   107,   107,   107,   107,   108,   109,   109,
     109,   110,   111,   112,   112,   113,   114,   114,   115,   115,
     115,   115,   115,   116,   117,   117,   118,   118,   119,   120,
     121,   121,   122,   122,   123,   124,   124,   125,   125,   126,
     126,   127,   127,   128,   128,   128,   128,   128,   128,   128,
     128,   128,   128,   128,   129,   129,   130,   130,   131,   131,
     132,   132,   132,   133,   133,   133,   134,   134,   135,   135,
     135,   135,   135,   136,   136,   137,   137,   137,   138,   138,
     139,   139,   139,   140,   140,   140,   140,   140,   140,   140,
     140,   140,   141,   141,   142,   142,   142,   143,   144,   144,
     145,   145,   146
};

/* YYR2[RULE-NUM] -- Number of symbols on the right-hand side of rule RULE-NUM.  */
static const yytype_int8 yyr2[] =
{
       0,     2,     2,     2,     2,     0,     1,     0,     7,     3,
       1,     0,     2,     4,     3,     1,     1,     3,     1,     3,
       1,     0,     1,     1,     1,     1,     2,     3,     3,     1,
       4,     2,     2,     0,     1,     1,     1,     1,     1,     1,
       1,     1,     1,     1,     1,     1,     1,     1,     1,     1,
       1,     1,     1,     2,     1,     2,     1,     3,     1,     1,
       1,     1,     1,     6,     3,     0,     5,     0,     4,     6,
       1,     4,     1,     2,     1,     1,     3,     1,     3,     2,
       1,     1,     3,     1,     1,     1,     1,     1,     1,     1,
       1,     2,     1,     2,     1,     3,     1,     3,     1,     3,
       1,     3,     3,     1,     3,     3,     1,     3,     1,     1,
       1,     1,     1,     2,     1,     1,     1,     1,     3,     1,
       1,     2,     3,     3,     2,     3,     1,     1,     1,     1,
       1,     1,     1,     3,     3,     3,     2,     5,     3,     0,
       1,     3,     1
};


enum { YYENOMEM = -2 };

#define yyerrok         (yyerrstatus = 0)
#define yyclearin       (yychar = YYEMPTY)

#define YYACCEPT        goto yyacceptlab
#define YYABORT         goto yyabortlab
#define YYERROR         goto yyerrorlab
#define YYNOMEM         goto yyexhaustedlab


#define YYRECOVERING()  (!!yyerrstatus)

#define YYBACKUP(Token, Value)                                    \
  do                                                              \
    if (yychar == YYEMPTY)                                        \
      {                                                           \
        yychar = (Token);                                         \
        yylval = (Value);                                         \
        YYPOPSTACK (yylen);                                       \
        yystate = *yyssp;                                         \
        goto yybackup;                                            \
      }                                                           \
    else                                                          \
      {                                                           \
        yyerror (YY_("syntax error: cannot back up")); \
        YYERROR;                                                  \
      }                                                           \
  while (0)

/* Backward compatibility with an undocumented macro.
   Use YYerror or YYUNDEF. */
#define YYERRCODE YYUNDEF


/* Enable debugging if requested.  */
#if YYDEBUG

# ifndef YYFPRINTF
#  include <stdio.h> /* INFRINGES ON USER NAME SPACE */
#  define YYFPRINTF fprintf
# endif

# define YYDPRINTF(Args)                        \
do {                                            \
  if (yydebug)                                  \
    YYFPRINTF Args;                             \
} while (0)




# define YY_SYMBOL_PRINT(Title, Kind, Value, Location)                    \
do {                                                                      \
  if (yydebug)                                                            \
    {                                                                     \
      YYFPRINTF (stderr, "%s ", Title);                                   \
      yy_symbol_print (stderr,                                            \
                  Kind, Value); \
      YYFPRINTF (stderr, "\n");                                           \
    }                                                                     \
} while (0)


/*-----------------------------------.
| Print this symbol's value on YYO.  |
`-----------------------------------*/

static void
yy_symbol_value_print (FILE *yyo,
                       yysymbol_kind_t yykind, YYSTYPE const * const yyvaluep)
{
  FILE *yyoutput = yyo;
  YY_USE (yyoutput);
  if (!yyvaluep)
    return;
  YY_IGNORE_MAYBE_UNINITIALIZED_BEGIN
  YY_USE (yykind);
  YY_IGNORE_MAYBE_UNINITIALIZED_END
}


/*---------------------------.
| Print this symbol on YYO.  |
`---------------------------*/

static void
yy_symbol_print (FILE *yyo,
                 yysymbol_kind_t yykind, YYSTYPE const * const yyvaluep)
{
  YYFPRINTF (yyo, "%s %s (",
             yykind < YYNTOKENS ? "token" : "nterm", yysymbol_name (yykind));

  yy_symbol_value_print (yyo, yykind, yyvaluep);
  YYFPRINTF (yyo, ")");
}

/*------------------------------------------------------------------.
| yy_stack_print -- Print the state stack from its BOTTOM up to its |
| TOP (included).                                                   |
`------------------------------------------------------------------*/

static void
yy_stack_print (yy_state_t *yybottom, yy_state_t *yytop)
{
  YYFPRINTF (stderr, "Stack now");
  for (; yybottom <= yytop; yybottom++)
    {
      int yybot = *yybottom;
      YYFPRINTF (stderr, " %d", yybot);
    }
  YYFPRINTF (stderr, "\n");
}

# define YY_STACK_PRINT(Bottom, Top)                            \
do {                                                            \
  if (yydebug)                                                  \
    yy_stack_print ((Bottom), (Top));                           \
} while (0)


/*------------------------------------------------.
| Report that the YYRULE is going to be reduced.  |
`------------------------------------------------*/

static void
yy_reduce_print (yy_state_t *yyssp, YYSTYPE *yyvsp,
                 int yyrule)
{
  int yylno = yyrline[yyrule];
  int yynrhs = yyr2[yyrule];
  int yyi;
  YYFPRINTF (stderr, "Reducing stack by rule %d (line %d):\n",
             yyrule - 1, yylno);
  /* The symbols being reduced.  */
  for (yyi = 0; yyi < yynrhs; yyi++)
    {
      YYFPRINTF (stderr, "   $%d = ", yyi + 1);
      yy_symbol_print (stderr,
                       YY_ACCESSING_SYMBOL (+yyssp[yyi + 1 - yynrhs]),
                       &yyvsp[(yyi + 1) - (yynrhs)]);
      YYFPRINTF (stderr, "\n");
    }
}

# define YY_REDUCE_PRINT(Rule)          \
do {                                    \
  if (yydebug)                          \
    yy_reduce_print (yyssp, yyvsp, Rule); \
} while (0)

/* Nonzero means print parse trace.  It is left uninitialized so that
   multiple parsers can coexist.  */
int yydebug;
#else /* !YYDEBUG */
# define YYDPRINTF(Args) ((void) 0)
# define YY_SYMBOL_PRINT(Title, Kind, Value, Location)
# define YY_STACK_PRINT(Bottom, Top)
# define YY_REDUCE_PRINT(Rule)
#endif /* !YYDEBUG */


/* YYINITDEPTH -- initial size of the parser's stacks.  */
#ifndef YYINITDEPTH
# define YYINITDEPTH 200
#endif

/* YYMAXDEPTH -- maximum size the stacks can grow to (effective only
   if the built-in stack extension method is used).

   Do not make this value too large; the results are undefined if
   YYSTACK_ALLOC_MAXIMUM < YYSTACK_BYTES (YYMAXDEPTH)
   evaluated with infinite-precision integer arithmetic.  */

#ifndef YYMAXDEPTH
# define YYMAXDEPTH 10000
#endif






/*-----------------------------------------------.
| Release the memory associated to this symbol.  |
`-----------------------------------------------*/

static void
yydestruct (const char *yymsg,
            yysymbol_kind_t yykind, YYSTYPE *yyvaluep)
{
  YY_USE (yyvaluep);
  if (!yymsg)
    yymsg = "Deleting";
  YY_SYMBOL_PRINT (yymsg, yykind, yyvaluep, yylocationp);

  YY_IGNORE_MAYBE_UNINITIALIZED_BEGIN
  YY_USE (yykind);
  YY_IGNORE_MAYBE_UNINITIALIZED_END
}


/* Lookahead token kind.  */
int yychar;

/* The semantic value of the lookahead symbol.  */
YYSTYPE yylval;
/* Number of syntax errors so far.  */
int yynerrs;




/*----------.
| yyparse.  |
`----------*/

int
yyparse (void)
{
    yy_state_fast_t yystate = 0;
    /* Number of tokens to shift before error messages enabled.  */
    int yyerrstatus = 0;

    /* Refer to the stacks through separate pointers, to allow yyoverflow
       to reallocate them elsewhere.  */

    /* Their size.  */
    YYPTRDIFF_T yystacksize = YYINITDEPTH;

    /* The state stack: array, bottom, top.  */
    yy_state_t yyssa[YYINITDEPTH];
    yy_state_t *yyss = yyssa;
    yy_state_t *yyssp = yyss;

    /* The semantic value stack: array, bottom, top.  */
    YYSTYPE yyvsa[YYINITDEPTH];
    YYSTYPE *yyvs = yyvsa;
    YYSTYPE *yyvsp = yyvs;

  int yyn;
  /* The return value of yyparse.  */
  int yyresult;
  /* Lookahead symbol kind.  */
  yysymbol_kind_t yytoken = YYSYMBOL_YYEMPTY;
  /* The variables used to return semantic value and location from the
     action routines.  */
  YYSTYPE yyval;



#define YYPOPSTACK(N)   (yyvsp -= (N), yyssp -= (N))

  /* The number of symbols on the RHS of the reduced rule.
     Keep to zero when no symbol should be popped.  */
  int yylen = 0;

  YYDPRINTF ((stderr, "Starting parse\n"));

  yychar = YYEMPTY; /* Cause a token to be read.  */

  goto yysetstate;


/*------------------------------------------------------------.
| yynewstate -- push a new state, which is found in yystate.  |
`------------------------------------------------------------*/
yynewstate:
  /* In all cases, when you get here, the value and location stacks
     have just been pushed.  So pushing a state here evens the stacks.  */
  yyssp++;


/*--------------------------------------------------------------------.
| yysetstate -- set current state (the top of the stack) to yystate.  |
`--------------------------------------------------------------------*/
yysetstate:
  YYDPRINTF ((stderr, "Entering state %d\n", yystate));
  YY_ASSERT (0 <= yystate && yystate < YYNSTATES);
  YY_IGNORE_USELESS_CAST_BEGIN
  *yyssp = YY_CAST (yy_state_t, yystate);
  YY_IGNORE_USELESS_CAST_END
  YY_STACK_PRINT (yyss, yyssp);

  if (yyss + yystacksize - 1 <= yyssp)
#if !defined yyoverflow && !defined YYSTACK_RELOCATE
    YYNOMEM;
#else
    {
      /* Get the current used size of the three stacks, in elements.  */
      YYPTRDIFF_T yysize = yyssp - yyss + 1;

# if defined yyoverflow
      {
        /* Give user a chance to reallocate the stack.  Use copies of
           these so that the &'s don't force the real ones into
           memory.  */
        yy_state_t *yyss1 = yyss;
        YYSTYPE *yyvs1 = yyvs;

        /* Each stack pointer address is followed by the size of the
           data in use in that stack, in bytes.  This used to be a
           conditional around just the two extra args, but that might
           be undefined if yyoverflow is a macro.  */
        yyoverflow (YY_("memory exhausted"),
                    &yyss1, yysize * YYSIZEOF (*yyssp),
                    &yyvs1, yysize * YYSIZEOF (*yyvsp),
                    &yystacksize);
        yyss = yyss1;
        yyvs = yyvs1;
      }
# else /* defined YYSTACK_RELOCATE */
      /* Extend the stack our own way.  */
      if (YYMAXDEPTH <= yystacksize)
        YYNOMEM;
      yystacksize *= 2;
      if (YYMAXDEPTH < yystacksize)
        yystacksize = YYMAXDEPTH;

      {
        yy_state_t *yyss1 = yyss;
        union yyalloc *yyptr =
          YY_CAST (union yyalloc *,
                   YYSTACK_ALLOC (YY_CAST (YYSIZE_T, YYSTACK_BYTES (yystacksize))));
        if (! yyptr)
          YYNOMEM;
        YYSTACK_RELOCATE (yyss_alloc, yyss);
        YYSTACK_RELOCATE (yyvs_alloc, yyvs);
#  undef YYSTACK_RELOCATE
        if (yyss1 != yyssa)
          YYSTACK_FREE (yyss1);
      }
# endif

      yyssp = yyss + yysize - 1;
      yyvsp = yyvs + yysize - 1;

      YY_IGNORE_USELESS_CAST_BEGIN
      YYDPRINTF ((stderr, "Stack size increased to %ld\n",
                  YY_CAST (long, yystacksize)));
      YY_IGNORE_USELESS_CAST_END

      if (yyss + yystacksize - 1 <= yyssp)
        YYABORT;
    }
#endif /* !defined yyoverflow && !defined YYSTACK_RELOCATE */


  if (yystate == YYFINAL)
    YYACCEPT;

  goto yybackup;


/*-----------.
| yybackup.  |
`-----------*/
yybackup:
  /* Do appropriate processing given the current state.  Read a
     lookahead token if we need one and don't already have one.  */

  /* First try to decide what to do without reference to lookahead token.  */
  yyn = yypact[yystate];
  if (yypact_value_is_default (yyn))
    goto yydefault;

  /* Not known => get a lookahead token if don't already have one.  */

  /* YYCHAR is either empty, or end-of-input, or a valid lookahead.  */
  if (yychar == YYEMPTY)
    {
      YYDPRINTF ((stderr, "Reading a token\n"));
      yychar = yylex ();
    }

  if (yychar <= YYEOF)
    {
      yychar = YYEOF;
      yytoken = YYSYMBOL_YYEOF;
      YYDPRINTF ((stderr, "Now at end of input.\n"));
    }
  else if (yychar == YYerror)
    {
      /* The scanner already issued an error message, process directly
         to error recovery.  But do not keep the error token as
         lookahead, it is too special and may lead us to an endless
         loop in error recovery. */
      yychar = YYUNDEF;
      yytoken = YYSYMBOL_YYerror;
      goto yyerrlab1;
    }
  else
    {
      yytoken = YYTRANSLATE (yychar);
      YY_SYMBOL_PRINT ("Next token is", yytoken, &yylval, &yylloc);
    }

  /* If the proper action on seeing token YYTOKEN is to reduce or to
     detect an error, take that action.  */
  yyn += yytoken;
  if (yyn < 0 || YYLAST < yyn || yycheck[yyn] != yytoken)
    goto yydefault;
  yyn = yytable[yyn];
  if (yyn <= 0)
    {
      if (yytable_value_is_error (yyn))
        goto yyerrlab;
      yyn = -yyn;
      goto yyreduce;
    }

  /* Count tokens shifted since error; after three, turn off error
     status.  */
  if (yyerrstatus)
    yyerrstatus--;

  /* Shift the lookahead token.  */
  YY_SYMBOL_PRINT ("Shifting", yytoken, &yylval, &yylloc);
  yystate = yyn;
  YY_IGNORE_MAYBE_UNINITIALIZED_BEGIN
  *++yyvsp = yylval;
  YY_IGNORE_MAYBE_UNINITIALIZED_END

  /* Discard the shifted token.  */
  yychar = YYEMPTY;
  goto yynewstate;


/*-----------------------------------------------------------.
| yydefault -- do the default action for the current state.  |
`-----------------------------------------------------------*/
yydefault:
  yyn = yydefact[yystate];
  if (yyn == 0)
    goto yyerrlab;
  goto yyreduce;


/*-----------------------------.
| yyreduce -- do a reduction.  |
`-----------------------------*/
yyreduce:
  /* yyn is the number of a rule to reduce with.  */
  yylen = yyr2[yyn];

  /* If YYLEN is nonzero, implement the default value of the action:
     '$$ = $1'.

     Otherwise, the following line sets YYVAL to garbage.
     This behavior is undocumented and Bison
     users should not rely upon it.  Assigning to YYVAL
     unconditionally makes the parser a bit smaller, and it avoids a
     GCC warning that YYVAL may be used uninitialized.  */
  yyval = yyvsp[1-yylen];


  YY_REDUCE_PRINT (yyn);
  switch (yyn)
    {
  case 2: /* file_input: nstatement ENDMARKER  */
#line 114 "parser.y"
                                {
    (yyval.ptr) = new node("nt", "file_input");
    ast.add_node((yyval.ptr));
    ast.add_edge((yyval.ptr), (yyvsp[-1].ptr));
    ast.add_edge((yyval.ptr), (yyvsp[0].ptr));
    root = (yyval.ptr);
    ast.graphviz((yyval.ptr));
    return 0;
}
#line 1446 "parser.tab.cpp"
    break;

  case 3: /* nstatement: nstatement NEWLINE  */
#line 124 "parser.y"
                               {
    (yyval.ptr) = new node("nt", "nstatement");
    ast.add_node((yyval.ptr));
    ast.add_edge((yyval.ptr), (yyvsp[-1].ptr));
    ast.add_edge((yyval.ptr), (yyvsp[0].ptr));
}
#line 1457 "parser.tab.cpp"
    break;

  case 4: /* nstatement: nstatement stmt  */
#line 129 "parser.y"
                    {
    (yyval.ptr) = new node("nt", "nstatement");
    ast.add_node((yyval.ptr));
    ast.add_edge((yyval.ptr), (yyvsp[-1].ptr));
    ast.add_edge((yyval.ptr), (yyvsp[0].ptr));
}
#line 1468 "parser.tab.cpp"
    break;

  case 5: /* nstatement: %empty  */
#line 134 "parser.y"
    {
    (yyval.ptr) = NULL;
}
#line 1476 "parser.tab.cpp"
    break;

  case 6: /* cond_arglist: arglist  */
#line 137 "parser.y"
                      {
    (yyval.ptr) = (yyvsp[0].ptr);
}
#line 1484 "parser.tab.cpp"
    break;

  case 7: /* cond_arglist: %empty  */
#line 140 "parser.y"
  {
    (yyval.ptr) = NULL;
}
#line 1492 "parser.tab.cpp"
    break;

  case 8: /* funcdef: DEF NAME parameters ARROWOP test ':' suite  */
#line 143 "parser.y"
                                                    {
    // cerr << "fundef\n";
    // present_table = present_table->parent;
    (yyval.ptr) = new node("nt", "funcdef");
    ast.add_node((yyval.ptr));
    ast.add_edge((yyval.ptr), (yyvsp[-6].ptr));
    ast.add_edge((yyval.ptr), (yyvsp[-5].ptr));
    ast.add_edge((yyval.ptr), (yyvsp[-4].ptr));
    ast.add_edge((yyval.ptr), (yyvsp[-3].ptr));
    ast.add_edge((yyval.ptr), (yyvsp[-2].ptr));
    ast.add_edge((yyval.ptr), (yyvsp[-1].ptr));
    ast.add_edge((yyval.ptr), (yyvsp[0].ptr));
}
#line 1510 "parser.tab.cpp"
    break;

  case 9: /* parameters: '(' cond_typedargslist ')'  */
#line 157 "parser.y"
                                       {
    (yyval.ptr) = new node("nt", "parameters");
    ast.add_node((yyval.ptr));
    ast.add_edge((yyval.ptr), (yyvsp[-2].ptr));
    ast.add_edge((yyval.ptr), (yyvsp[-1].ptr));
    ast.add_edge((yyval.ptr), (yyvsp[0].ptr));
}
#line 1522 "parser.tab.cpp"
    break;

  case 10: /* cond_typedargslist: typedargslist  */
#line 164 "parser.y"
                                  {
    (yyval.ptr) = (yyvsp[0].ptr);
}
#line 1530 "parser.tab.cpp"
    break;

  case 11: /* cond_typedargslist: %empty  */
#line 166 "parser.y"
    {
    (yyval.ptr) = NULL;
}
#line 1538 "parser.tab.cpp"
    break;

  case 12: /* typedargslist: tfpdef cond_eqtest  */
#line 170 "parser.y"
                                 {
    (yyval.ptr) = new node("nt", "typedarglist");
    ast.add_edge((yyval.ptr), (yyvsp[-1].ptr));
    ast.add_edge((yyval.ptr), (yyvsp[0].ptr));
    // cerr << "ptht " << $<ptr>$ << ' ' << $<ptr>$->children.size() << '\n';
}
#line 1549 "parser.tab.cpp"
    break;

  case 13: /* typedargslist: typedargslist ',' tfpdef cond_eqtest  */
#line 175 "parser.y"
                                        {
    (yyval.ptr) = new node("nt", "typedarglist");
    ast.add_edge((yyval.ptr), (yyvsp[-3].ptr));
    ast.add_edge((yyval.ptr), (yyvsp[-2].ptr));
    ast.add_edge((yyval.ptr), (yyvsp[-1].ptr));
    ast.add_edge((yyval.ptr), (yyvsp[0].ptr));
}
#line 1561 "parser.tab.cpp"
    break;

  case 14: /* tfpdef: NAME ':' test  */
#line 183 "parser.y"
                      {
    (yyval.ptr) = new node("nt", "tfpdef");
    ast.add_node((yyval.ptr));
    ast.add_edge((yyval.ptr), (yyvsp[-2].ptr));
    ast.add_edge((yyval.ptr), (yyvsp[-1].ptr));
    ast.add_edge((yyval.ptr), (yyvsp[0].ptr));
}
#line 1573 "parser.tab.cpp"
    break;

  case 15: /* stmt: simple_stmt  */
#line 192 "parser.y"
                  {
    (yyval.ptr) = (yyvsp[0].ptr);
}
#line 1581 "parser.tab.cpp"
    break;

  case 16: /* stmt: compound_stmt  */
#line 194 "parser.y"
                  {
    (yyval.ptr) = (yyvsp[0].ptr);
}
#line 1589 "parser.tab.cpp"
    break;

  case 17: /* simple_stmt: small_stmts cond_semi_colon NEWLINE  */
#line 197 "parser.y"
                                                 {
        (yyval.ptr) = new node("nt", "simple_stmt");
        ast.add_edge((yyval.ptr), (yyvsp[-2].ptr));
        ast.add_edge((yyval.ptr), (yyvsp[-1].ptr));
        ast.add_edge((yyval.ptr), (yyvsp[0].ptr));
    }
#line 1600 "parser.tab.cpp"
    break;

  case 18: /* small_stmts: small_stmt  */
#line 204 "parser.y"
                        {
    (yyval.ptr) = (yyvsp[0].ptr);
}
#line 1608 "parser.tab.cpp"
    break;

  case 19: /* small_stmts: small_stmts ';' small_stmt  */
#line 206 "parser.y"
                               {
    (yyval.ptr) = new node("nt", "small_stmts");
    ast.add_edge((yyval.ptr), (yyvsp[-2].ptr));
    ast.add_edge((yyval.ptr), (yyvsp[-1].ptr));
    ast.add_edge((yyval.ptr), (yyvsp[0].ptr));
}
#line 1619 "parser.tab.cpp"
    break;

  case 20: /* cond_semi_colon: ';'  */
#line 212 "parser.y"
                     {
        (yyval.ptr) = (yyvsp[0].ptr);
    }
#line 1627 "parser.tab.cpp"
    break;

  case 21: /* cond_semi_colon: %empty  */
#line 215 "parser.y"
      {
        (yyval.ptr) = NULL;
    }
#line 1635 "parser.tab.cpp"
    break;

  case 22: /* small_stmt: expr_stmt  */
#line 218 "parser.y"
                      {
    (yyval.ptr) = (yyvsp[0].ptr);
}
#line 1643 "parser.tab.cpp"
    break;

  case 23: /* small_stmt: pass_stmt  */
#line 221 "parser.y"
            {
    (yyval.ptr) = (yyvsp[0].ptr);
}
#line 1651 "parser.tab.cpp"
    break;

  case 24: /* small_stmt: flow_stmt  */
#line 224 "parser.y"
            {
    (yyval.ptr) = (yyvsp[0].ptr);
}
#line 1659 "parser.tab.cpp"
    break;

  case 25: /* small_stmt: global_stmt  */
#line 227 "parser.y"
              {
    (yyval.ptr) = (yyvsp[0].ptr);
}
#line 1667 "parser.tab.cpp"
    break;

  case 26: /* expr_stmt: test annassign  */
#line 230 "parser.y"
                          {
    (yyval.ptr) = new node("nt", "expr_stmt");
    ast.add_node((yyval.ptr));
    ast.add_edge((yyval.ptr), (yyvsp[-1].ptr));
    ast.add_edge((yyval.ptr), (yyvsp[0].ptr));
}
#line 1678 "parser.tab.cpp"
    break;

  case 27: /* expr_stmt: test augassign test  */
#line 235 "parser.y"
                        {
    (yyval.ptr) = new node("nt", "expr_stmt");
    ast.add_node((yyval.ptr));
    ast.add_edge((yyval.ptr), (yyvsp[-2].ptr));
    ast.add_edge((yyval.ptr), (yyvsp[-1].ptr));
    ast.add_edge((yyval.ptr), (yyvsp[0].ptr));
}
#line 1690 "parser.tab.cpp"
    break;

  case 28: /* expr_stmt: test '=' test  */
#line 241 "parser.y"
                  { 
    (yyval.ptr) = new node("nt", "expr_stmt");
    ast.add_node((yyval.ptr));
    ast.add_edge((yyval.ptr), (yyvsp[-2].ptr));
    ast.add_edge((yyval.ptr), (yyvsp[-1].ptr));
    ast.add_edge((yyval.ptr), (yyvsp[0].ptr));
}
#line 1702 "parser.tab.cpp"
    break;

  case 29: /* expr_stmt: test  */
#line 247 "parser.y"
         {
    (yyval.ptr) = new node("nt", "expr_stmt");
    ast.add_edge((yyval.ptr), (yyvsp[0].ptr));
}
#line 1711 "parser.tab.cpp"
    break;

  case 30: /* annassign: ':' test '=' test  */
#line 251 "parser.y"
                             {
    (yyval.ptr) = new node("nt", "annasign");
    ast.add_edge((yyval.ptr), (yyvsp[-3].ptr));
    ast.add_edge((yyval.ptr), (yyvsp[-2].ptr));
    ast.add_edge((yyval.ptr), (yyvsp[-1].ptr));
    ast.add_edge((yyval.ptr), (yyvsp[0].ptr));
}
#line 1723 "parser.tab.cpp"
    break;

  case 31: /* annassign: ':' test  */
#line 257 "parser.y"
             { 
    (yyval.ptr) = new node("nt", "annasign");
    ast.add_edge((yyval.ptr), (yyvsp[-1].ptr));
    ast.add_edge((yyval.ptr), (yyvsp[0].ptr));
}
#line 1733 "parser.tab.cpp"
    break;

  case 32: /* cond_eqtest: '=' test  */
#line 262 "parser.y"
                      {
        (yyval.ptr) = new node("nt", "cond_eqtest");
        ast.add_node((yyval.ptr));
        ast.add_edge((yyval.ptr), (yyvsp[-1].ptr));
        ast.add_edge((yyval.ptr), (yyvsp[0].ptr));
    }
#line 1744 "parser.tab.cpp"
    break;

  case 33: /* cond_eqtest: %empty  */
#line 268 "parser.y"
        {
        (yyval.ptr) = NULL;
      }
#line 1752 "parser.tab.cpp"
    break;

  case 34: /* augassign: ADDASSIGN  */
#line 273 "parser.y"
                    {
            (yyval.ptr) = (yyvsp[0].ptr);
        }
#line 1760 "parser.tab.cpp"
    break;

  case 35: /* augassign: SUBASSIGN  */
#line 276 "parser.y"
                        {
                (yyval.ptr) = (yyvsp[0].ptr);
            }
#line 1768 "parser.tab.cpp"
    break;

  case 36: /* augassign: MULASSIGN  */
#line 279 "parser.y"
                        {
                (yyval.ptr) = (yyvsp[0].ptr);
            }
#line 1776 "parser.tab.cpp"
    break;

  case 37: /* augassign: ATASSIGN  */
#line 282 "parser.y"
                       {
                (yyval.ptr) = (yyvsp[0].ptr);
            }
#line 1784 "parser.tab.cpp"
    break;

  case 38: /* augassign: DIVASSIGN  */
#line 285 "parser.y"
                        {
                (yyval.ptr) = (yyvsp[0].ptr);
            }
#line 1792 "parser.tab.cpp"
    break;

  case 39: /* augassign: MODASSIGN  */
#line 288 "parser.y"
                        {
                (yyval.ptr) = (yyvsp[0].ptr);
            }
#line 1800 "parser.tab.cpp"
    break;

  case 40: /* augassign: ANDASSIGN  */
#line 291 "parser.y"
                        {
                (yyval.ptr) = (yyvsp[0].ptr);
            }
#line 1808 "parser.tab.cpp"
    break;

  case 41: /* augassign: ORASSIGN  */
#line 294 "parser.y"
                       {
                (yyval.ptr) = (yyvsp[0].ptr);
            }
#line 1816 "parser.tab.cpp"
    break;

  case 42: /* augassign: XORASSIGN  */
#line 297 "parser.y"
                        {
                (yyval.ptr) = (yyvsp[0].ptr);
            }
#line 1824 "parser.tab.cpp"
    break;

  case 43: /* augassign: LSASSIGN  */
#line 300 "parser.y"
                       {
                (yyval.ptr) = (yyvsp[0].ptr);
            }
#line 1832 "parser.tab.cpp"
    break;

  case 44: /* augassign: RSASSIGN  */
#line 303 "parser.y"
                       {
                (yyval.ptr) = (yyvsp[0].ptr);
            }
#line 1840 "parser.tab.cpp"
    break;

  case 45: /* augassign: POWASSIGN  */
#line 306 "parser.y"
                        {
                (yyval.ptr) = (yyvsp[0].ptr);
            }
#line 1848 "parser.tab.cpp"
    break;

  case 46: /* augassign: IDIVASSIGN  */
#line 309 "parser.y"
                         {
                (yyval.ptr) = (yyvsp[0].ptr);
            }
#line 1856 "parser.tab.cpp"
    break;

  case 47: /* pass_stmt: PASS  */
#line 312 "parser.y"
               {
    (yyval.ptr) = (yyvsp[0].ptr);
}
#line 1864 "parser.tab.cpp"
    break;

  case 48: /* flow_stmt: break_stmt  */
#line 315 "parser.y"
                      {
            (yyval.ptr) = (yyvsp[0].ptr);
        }
#line 1872 "parser.tab.cpp"
    break;

  case 49: /* flow_stmt: continue_stmt  */
#line 318 "parser.y"
                        {
            (yyval.ptr) = (yyvsp[0].ptr);
        }
#line 1880 "parser.tab.cpp"
    break;

  case 50: /* flow_stmt: return_stmt  */
#line 321 "parser.y"
                      {
            (yyval.ptr) = (yyvsp[0].ptr);
        }
#line 1888 "parser.tab.cpp"
    break;

  case 51: /* break_stmt: BREAK  */
#line 325 "parser.y"
                  {
    (yyval.ptr) = new node("nt", "break_stmt");
    ast.add_node((yyval.ptr));
    ast.add_edge((yyval.ptr), (yyvsp[0].ptr));
}
#line 1898 "parser.tab.cpp"
    break;

  case 52: /* continue_stmt: CONTINUE  */
#line 331 "parser.y"
                        {
    (yyval.ptr) = new node("nt", "continue_stmt");
    ast.add_node((yyval.ptr));
    ast.add_edge((yyval.ptr), (yyvsp[0].ptr));
}
#line 1908 "parser.tab.cpp"
    break;

  case 53: /* return_stmt: RETURN test  */
#line 337 "parser.y"
                        {
    (yyval.ptr) = new node("nt", "return_stmt");
    ast.add_node((yyval.ptr));
    ast.add_edge((yyval.ptr), (yyvsp[-1].ptr));
    ast.add_edge((yyval.ptr), (yyvsp[0].ptr));
}
#line 1919 "parser.tab.cpp"
    break;

  case 54: /* return_stmt: RETURN  */
#line 342 "parser.y"
            {
    (yyval.ptr) = new node("nt", "return_stmt");
    ast.add_edge((yyval.ptr), (yyvsp[0].ptr));
    // $<ptr>$ = $<ptr>1;
}
#line 1929 "parser.tab.cpp"
    break;

  case 55: /* global_stmt: GLOBAL namelist  */
#line 348 "parser.y"
                            {
    (yyval.ptr) = new node("nt", "global_stmt");
    ast.add_edge((yyval.ptr), (yyvsp[-1].ptr));
    ast.add_edge((yyval.ptr), (yyvsp[0].ptr));
}
#line 1939 "parser.tab.cpp"
    break;

  case 56: /* namelist: NAME  */
#line 354 "parser.y"
               {
    (yyval.ptr) = (yyvsp[0].ptr);
}
#line 1947 "parser.tab.cpp"
    break;

  case 57: /* namelist: namelist ',' NAME  */
#line 356 "parser.y"
                      {
    (yyval.ptr) = new node("nt", "namelist");
    ast.add_edge((yyval.ptr), (yyvsp[-2].ptr));
    ast.add_edge((yyval.ptr), (yyvsp[-1].ptr));
    ast.add_edge((yyval.ptr), (yyvsp[0].ptr));
}
#line 1958 "parser.tab.cpp"
    break;

  case 58: /* compound_stmt: if_stmt  */
#line 364 "parser.y"
                      {
    (yyval.ptr) = (yyvsp[0].ptr);
}
#line 1966 "parser.tab.cpp"
    break;

  case 59: /* compound_stmt: while_stmt  */
#line 366 "parser.y"
              {
    (yyval.ptr) = (yyvsp[0].ptr);
}
#line 1974 "parser.tab.cpp"
    break;

  case 60: /* compound_stmt: for_stmt  */
#line 368 "parser.y"
            {
    (yyval.ptr) = (yyvsp[0].ptr);
}
#line 1982 "parser.tab.cpp"
    break;

  case 61: /* compound_stmt: funcdef  */
#line 370 "parser.y"
           {
    // cerr << "here\n";
    (yyval.ptr) = (yyvsp[0].ptr);
}
#line 1991 "parser.tab.cpp"
    break;

  case 62: /* compound_stmt: classdef  */
#line 373 "parser.y"
            {
    (yyval.ptr) = (yyvsp[0].ptr);
}
#line 1999 "parser.tab.cpp"
    break;

  case 63: /* if_stmt: IF test ':' suite close_eliftestsuite cond_else_colon_suite  */
#line 377 "parser.y"
                                                                    {
    (yyval.ptr) = new node("nt", "if_stmt");
    ast.add_edge((yyval.ptr), (yyvsp[-5].ptr));
    ast.add_edge((yyval.ptr), (yyvsp[-4].ptr));
    ast.add_edge((yyval.ptr), (yyvsp[-3].ptr));
    ast.add_edge((yyval.ptr), (yyvsp[-2].ptr));
    ast.add_edge((yyval.ptr), (yyvsp[-1].ptr));
    ast.add_edge((yyval.ptr), (yyvsp[0].ptr));
}
#line 2013 "parser.tab.cpp"
    break;

  case 64: /* cond_else_colon_suite: ELSE ':' suite  */
#line 387 "parser.y"
                                     {
    (yyval.ptr) = new node("nt", "cond_else_colon_suite");
    ast.add_edge((yyval.ptr), (yyvsp[-2].ptr));
    ast.add_edge((yyval.ptr), (yyvsp[-1].ptr));
    ast.add_edge((yyval.ptr), (yyvsp[0].ptr));
}
#line 2024 "parser.tab.cpp"
    break;

  case 65: /* cond_else_colon_suite: %empty  */
#line 392 "parser.y"
    {
    (yyval.ptr) = NULL;
}
#line 2032 "parser.tab.cpp"
    break;

  case 66: /* close_eliftestsuite: close_eliftestsuite ELIF test ':' suite  */
#line 396 "parser.y"
                                                            {
    (yyval.ptr) = new node("nt", "close_eliftestsuite");
    ast.add_edge((yyval.ptr), (yyvsp[-4].ptr));
    ast.add_edge((yyval.ptr), (yyvsp[-3].ptr));
    ast.add_edge((yyval.ptr), (yyvsp[-2].ptr));
    ast.add_edge((yyval.ptr), (yyvsp[-1].ptr));
    ast.add_edge((yyval.ptr), (yyvsp[0].ptr));
}
#line 2045 "parser.tab.cpp"
    break;

  case 67: /* close_eliftestsuite: %empty  */
#line 403 "parser.y"
    {
    (yyval.ptr) = NULL;
}
#line 2053 "parser.tab.cpp"
    break;

  case 68: /* while_stmt: WHILE test ':' suite  */
#line 407 "parser.y"
                                {
    (yyval.ptr) = new node("nt", "while_stmt");
    ast.add_edge((yyval.ptr), (yyvsp[-3].ptr));
    ast.add_edge((yyval.ptr), (yyvsp[-2].ptr));
    ast.add_edge((yyval.ptr), (yyvsp[-1].ptr));
    ast.add_edge((yyval.ptr), (yyvsp[0].ptr));
}
#line 2065 "parser.tab.cpp"
    break;

  case 69: /* for_stmt: FOR NAME IN test ':' suite  */
#line 414 "parser.y"
                                    {
    (yyval.ptr) = new node("nt", "for_stmt");
    ast.add_edge((yyval.ptr), (yyvsp[-5].ptr));
    ast.add_edge((yyval.ptr), (yyvsp[-4].ptr));
    ast.add_edge((yyval.ptr), (yyvsp[-3].ptr));
    ast.add_edge((yyval.ptr), (yyvsp[-2].ptr));
    ast.add_edge((yyval.ptr), (yyvsp[-1].ptr));
    ast.add_edge((yyval.ptr), (yyvsp[0].ptr));
}
#line 2079 "parser.tab.cpp"
    break;

  case 70: /* suite: simple_stmt  */
#line 424 "parser.y"
                  {
    (yyval.ptr) = (yyvsp[0].ptr);
}
#line 2087 "parser.tab.cpp"
    break;

  case 71: /* suite: NEWLINE INDENT plus_stmt DEDENT  */
#line 426 "parser.y"
                                   {
    (yyval.ptr) = new node("nt", "suite");
    ast.add_edge((yyval.ptr), (yyvsp[-3].ptr));
    ast.add_edge((yyval.ptr), (yyvsp[-2].ptr));
    ast.add_edge((yyval.ptr), (yyvsp[-1].ptr));
    ast.add_edge((yyval.ptr), (yyvsp[0].ptr));
}
#line 2099 "parser.tab.cpp"
    break;

  case 72: /* plus_stmt: stmt  */
#line 433 "parser.y"
               {
    (yyval.ptr) = (yyvsp[0].ptr);
}
#line 2107 "parser.tab.cpp"
    break;

  case 73: /* plus_stmt: plus_stmt stmt  */
#line 435 "parser.y"
                  {
    (yyval.ptr) = new node("nt", "plus_stmt");
    ast.add_node((yyval.ptr));
    ast.add_edge((yyval.ptr), (yyvsp[-1].ptr));
    ast.add_edge((yyval.ptr), (yyvsp[0].ptr));
}
#line 2118 "parser.tab.cpp"
    break;

  case 74: /* test: or_test  */
#line 441 "parser.y"
             {
    // cerr << "here test\n";
    (yyval.ptr) = new node("nt", "test");
    ast.add_edge((yyval.ptr), (yyvsp[0].ptr));
    // $<ptr>$ = $<ptr>1;
}
#line 2129 "parser.tab.cpp"
    break;

  case 75: /* or_test: and_test  */
#line 447 "parser.y"
                  {
    (yyval.ptr) = new node("nt", "or_test");
    ast.add_edge((yyval.ptr), (yyvsp[0].ptr));
    // $<ptr>$ = $<ptr>1;
}
#line 2139 "parser.tab.cpp"
    break;

  case 76: /* or_test: or_test OR and_test  */
#line 451 "parser.y"
                        {
    (yyval.ptr) = new node("nt", "or_test");
    ast.add_edge((yyval.ptr), (yyvsp[-2].ptr));
    ast.add_edge((yyval.ptr), (yyvsp[-1].ptr));
    ast.add_edge((yyval.ptr), (yyvsp[0].ptr));
}
#line 2150 "parser.tab.cpp"
    break;

  case 77: /* and_test: not_test  */
#line 458 "parser.y"
                  {
    (yyval.ptr) = new node("nt", "and_test");
    ast.add_edge((yyval.ptr), (yyvsp[0].ptr));
    // $<ptr>$ = $<ptr>1;
}
#line 2160 "parser.tab.cpp"
    break;

  case 78: /* and_test: and_test AND not_test  */
#line 462 "parser.y"
                          {
    (yyval.ptr) = new node("nt", "and_test");
    ast.add_edge((yyval.ptr), (yyvsp[-2].ptr));
    ast.add_edge((yyval.ptr), (yyvsp[-1].ptr));
    ast.add_edge((yyval.ptr), (yyvsp[0].ptr));
}
#line 2171 "parser.tab.cpp"
    break;

  case 79: /* not_test: NOT not_test  */
#line 469 "parser.y"
                       {
    (yyval.ptr) = new node("nt", "not_test");
    ast.add_edge((yyval.ptr), (yyvsp[-1].ptr));
    ast.add_edge((yyval.ptr), (yyvsp[0].ptr));
}
#line 2181 "parser.tab.cpp"
    break;

  case 80: /* not_test: comparison  */
#line 473 "parser.y"
               {
    (yyval.ptr) = new node("nt", "not_test");
    ast.add_edge((yyval.ptr), (yyvsp[0].ptr));
    // $<ptr>$ = $<ptr>1;
}
#line 2191 "parser.tab.cpp"
    break;

  case 81: /* comparison: expr  */
#line 479 "parser.y"
                 {
    (yyval.ptr) = new node("nt", "comparison");
    ast.add_edge((yyval.ptr), (yyvsp[0].ptr));
    // $<ptr>$ = $<ptr>1;
}
#line 2201 "parser.tab.cpp"
    break;

  case 82: /* comparison: comparison comp_op expr  */
#line 483 "parser.y"
                            {
    (yyval.ptr) = new node("nt", "comparison");
    ast.add_edge((yyval.ptr), (yyvsp[-2].ptr));
    ast.add_edge((yyval.ptr), (yyvsp[-1].ptr));
    ast.add_edge((yyval.ptr), (yyvsp[0].ptr));
}
#line 2212 "parser.tab.cpp"
    break;

  case 83: /* comp_op: '<'  */
#line 495 "parser.y"
            {
    (yyval.ptr) = (yyvsp[0].ptr);
}
#line 2220 "parser.tab.cpp"
    break;

  case 84: /* comp_op: '>'  */
#line 497 "parser.y"
       {
    (yyval.ptr) = (yyvsp[0].ptr);
}
#line 2228 "parser.tab.cpp"
    break;

  case 85: /* comp_op: EQUAL  */
#line 499 "parser.y"
         {
    (yyval.ptr) = (yyvsp[0].ptr);
}
#line 2236 "parser.tab.cpp"
    break;

  case 86: /* comp_op: GEQ  */
#line 501 "parser.y"
       {
    (yyval.ptr) = (yyvsp[0].ptr);
}
#line 2244 "parser.tab.cpp"
    break;

  case 87: /* comp_op: LEQ  */
#line 503 "parser.y"
       {
    (yyval.ptr) = (yyvsp[0].ptr);
}
#line 2252 "parser.tab.cpp"
    break;

  case 88: /* comp_op: LTORGT  */
#line 505 "parser.y"
          {
    (yyval.ptr) = (yyvsp[0].ptr);
}
#line 2260 "parser.tab.cpp"
    break;

  case 89: /* comp_op: NEQ  */
#line 507 "parser.y"
       {
    (yyval.ptr) = (yyvsp[0].ptr);
}
#line 2268 "parser.tab.cpp"
    break;

  case 90: /* comp_op: IN  */
#line 509 "parser.y"
      {
    (yyval.ptr) = (yyvsp[0].ptr);
}
#line 2276 "parser.tab.cpp"
    break;

  case 91: /* comp_op: NOT IN  */
#line 511 "parser.y"
          {
    (yyval.ptr) = new node("nt", "comp_op");
    ast.add_node((yyval.ptr));
    ast.add_edge((yyval.ptr), (yyvsp[-1].ptr));
    ast.add_edge((yyval.ptr), (yyvsp[0].ptr));
}
#line 2287 "parser.tab.cpp"
    break;

  case 92: /* comp_op: IS  */
#line 516 "parser.y"
      {
    (yyval.ptr) = (yyvsp[0].ptr);
}
#line 2295 "parser.tab.cpp"
    break;

  case 93: /* comp_op: IS NOT  */
#line 518 "parser.y"
          {
    (yyval.ptr) = new node("nt", "comp_op");
    ast.add_node((yyval.ptr));
    ast.add_edge((yyval.ptr), (yyvsp[-1].ptr));
    ast.add_edge((yyval.ptr), (yyvsp[0].ptr));
}
#line 2306 "parser.tab.cpp"
    break;

  case 94: /* expr: xor_expr  */
#line 526 "parser.y"
              {
    // cerr << "here expr\n";
    (yyval.ptr) = new node("nt", "expr");
    ast.add_edge((yyval.ptr), (yyvsp[0].ptr));
    // $<ptr>$ = $<ptr>1;
}
#line 2317 "parser.tab.cpp"
    break;

  case 95: /* expr: expr '|' xor_expr  */
#line 531 "parser.y"
                      {
    (yyval.ptr) = new node("nt", "expr");
    ast.add_edge((yyval.ptr), (yyvsp[-2].ptr));
    ast.add_edge((yyval.ptr), (yyvsp[-1].ptr));
    ast.add_edge((yyval.ptr), (yyvsp[0].ptr));
}
#line 2328 "parser.tab.cpp"
    break;

  case 96: /* xor_expr: and_expr  */
#line 538 "parser.y"
                  {
    (yyval.ptr) = new node("nt", "xor_expr");
    ast.add_edge((yyval.ptr), (yyvsp[0].ptr));
    // $<ptr>$ = $<ptr>1;
}
#line 2338 "parser.tab.cpp"
    break;

  case 97: /* xor_expr: xor_expr '^' and_expr  */
#line 542 "parser.y"
                          {
    (yyval.ptr) = new node("nt", "xor_expr");
    ast.add_node((yyval.ptr));
    ast.add_edge((yyval.ptr), (yyvsp[-2].ptr));
    ast.add_edge((yyval.ptr), (yyvsp[-1].ptr));
}
#line 2349 "parser.tab.cpp"
    break;

  case 98: /* and_expr: shift_expr  */
#line 549 "parser.y"
                    {
    (yyval.ptr) = new node("nt", "and_expr");
    ast.add_edge((yyval.ptr), (yyvsp[0].ptr));
    // $<ptr>$ = $<ptr>1;
}
#line 2359 "parser.tab.cpp"
    break;

  case 99: /* and_expr: and_expr '&' shift_expr  */
#line 553 "parser.y"
                           {
    (yyval.ptr) = new node("nt", "and_expr");
    ast.add_edge((yyval.ptr), (yyvsp[-2].ptr));
    ast.add_edge((yyval.ptr), (yyvsp[-1].ptr));
    ast.add_edge((yyval.ptr), (yyvsp[0].ptr));
}
#line 2370 "parser.tab.cpp"
    break;

  case 100: /* shift_expr: arith_expr  */
#line 561 "parser.y"
                       {
    (yyval.ptr) = new node("nt", "shift_expr");
    ast.add_edge((yyval.ptr), (yyvsp[0].ptr));
    // $<ptr>$ = $<ptr>1;
}
#line 2380 "parser.tab.cpp"
    break;

  case 101: /* shift_expr: shift_expr LEFTSHIFT arith_expr  */
#line 565 "parser.y"
                                    {
    (yyval.ptr) = new node("nt", "shift_expr");
    ast.add_edge((yyval.ptr), (yyvsp[-2].ptr));
    ast.add_edge((yyval.ptr), (yyvsp[-1].ptr));
    ast.add_edge((yyval.ptr), (yyvsp[0].ptr));
}
#line 2391 "parser.tab.cpp"
    break;

  case 102: /* shift_expr: shift_expr RIGHTSHIFT arith_expr  */
#line 570 "parser.y"
                                     {
    (yyval.ptr) = new node("nt", "shift_expr");
    ast.add_node((yyval.ptr));
    ast.add_edge((yyval.ptr), (yyvsp[-2].ptr));
    ast.add_edge((yyval.ptr), (yyvsp[-1].ptr));
    ast.add_edge((yyval.ptr), (yyvsp[0].ptr));

}
#line 2404 "parser.tab.cpp"
    break;

  case 103: /* arith_expr: term  */
#line 580 "parser.y"
                {
    (yyval.ptr) = (yyvsp[0].ptr);
}
#line 2412 "parser.tab.cpp"
    break;

  case 104: /* arith_expr: arith_expr '+' term  */
#line 582 "parser.y"
                        {
    (yyval.ptr) = new node("nt", "arith_expr");
    ast.add_edge((yyval.ptr), (yyvsp[-2].ptr));
    ast.add_edge((yyval.ptr), (yyvsp[-1].ptr));
    ast.add_edge((yyval.ptr), (yyvsp[0].ptr));
}
#line 2423 "parser.tab.cpp"
    break;

  case 105: /* arith_expr: arith_expr '-' term  */
#line 587 "parser.y"
                        {
    (yyval.ptr) = new node("nt", "arith_expr");
    ast.add_edge((yyval.ptr), (yyvsp[-2].ptr));
    ast.add_edge((yyval.ptr), (yyvsp[-1].ptr));
    ast.add_edge((yyval.ptr), (yyvsp[0].ptr));
}
#line 2434 "parser.tab.cpp"
    break;

  case 106: /* term: factor  */
#line 595 "parser.y"
            {
    // cerr<<"here term \n";
    (yyval.ptr) = new node("nt", "term");
    ast.add_edge((yyval.ptr), (yyvsp[0].ptr));
    // $<ptr>$ = $<ptr>1;
}
#line 2445 "parser.tab.cpp"
    break;

  case 107: /* term: term muldivremops factor  */
#line 600 "parser.y"
                             {
    (yyval.ptr) = new node("nt", "term");
    ast.add_node((yyval.ptr));
    ast.add_edge((yyval.ptr), (yyvsp[-2].ptr));
    ast.add_edge((yyval.ptr), (yyvsp[-1].ptr));
    ast.add_edge((yyval.ptr), (yyvsp[0].ptr));
}
#line 2457 "parser.tab.cpp"
    break;

  case 108: /* muldivremops: '*'  */
#line 608 "parser.y"
                 {
    (yyval.ptr) = (yyvsp[0].ptr);
}
#line 2465 "parser.tab.cpp"
    break;

  case 109: /* muldivremops: '@'  */
#line 610 "parser.y"
       {
    (yyval.ptr) = (yyvsp[0].ptr);
}
#line 2473 "parser.tab.cpp"
    break;

  case 110: /* muldivremops: '/'  */
#line 612 "parser.y"
       {
    (yyval.ptr) = (yyvsp[0].ptr);
}
#line 2481 "parser.tab.cpp"
    break;

  case 111: /* muldivremops: '%'  */
#line 614 "parser.y"
       {
    (yyval.ptr) = (yyvsp[0].ptr);
}
#line 2489 "parser.tab.cpp"
    break;

  case 112: /* muldivremops: IDIV  */
#line 616 "parser.y"
        {
    (yyval.ptr) = (yyvsp[0].ptr);
}
#line 2497 "parser.tab.cpp"
    break;

  case 113: /* factor: plus_or_minus_or_not factor  */
#line 620 "parser.y"
                                   {
    (yyval.ptr) = new node("nt", "factor");
    ast.add_node((yyval.ptr));
    ast.add_edge((yyval.ptr), (yyvsp[-1].ptr));
    ast.add_edge((yyval.ptr), (yyvsp[0].ptr));
}
#line 2508 "parser.tab.cpp"
    break;

  case 114: /* factor: power  */
#line 625 "parser.y"
          {
    // cerr<<"here factor \n";
    (yyval.ptr) = new node("nt", "factor");
    ast.add_edge((yyval.ptr), (yyvsp[0].ptr));
    // $<ptr>$ = $<ptr>1;
}
#line 2519 "parser.tab.cpp"
    break;

  case 115: /* plus_or_minus_or_not: '+'  */
#line 634 "parser.y"
                         {
    (yyval.ptr) = (yyvsp[0].ptr);
}
#line 2527 "parser.tab.cpp"
    break;

  case 116: /* plus_or_minus_or_not: '-'  */
#line 636 "parser.y"
       {
    (yyval.ptr) = (yyvsp[0].ptr);
}
#line 2535 "parser.tab.cpp"
    break;

  case 117: /* plus_or_minus_or_not: '~'  */
#line 638 "parser.y"
       {
    (yyval.ptr) = (yyvsp[0].ptr);
}
#line 2543 "parser.tab.cpp"
    break;

  case 118: /* power: atom_expr POW factor  */
#line 642 "parser.y"
                           {
    (yyval.ptr) = new node("nt", "power");
    ast.add_edge((yyval.ptr), (yyvsp[-2].ptr));
    ast.add_edge((yyval.ptr), (yyvsp[-1].ptr));
    ast.add_edge((yyval.ptr), (yyvsp[0].ptr));
}
#line 2554 "parser.tab.cpp"
    break;

  case 119: /* power: atom_expr  */
#line 647 "parser.y"
             {
    // <<"here power \n";
    (yyval.ptr) = new node("nt", "power");
    ast.add_edge((yyval.ptr), (yyvsp[0].ptr));
}
#line 2564 "parser.tab.cpp"
    break;

  case 120: /* atom_expr: atom  */
#line 653 "parser.y"
                {
    (yyval.ptr) = new node("nt", "atom_expr");
    ast.add_edge((yyval.ptr), (yyvsp[0].ptr));
    // $<ptr>$ = $<ptr>1;
}
#line 2574 "parser.tab.cpp"
    break;

  case 121: /* atom_expr: atom trailer  */
#line 657 "parser.y"
                 {  // Function calls, object attr access only
    // cerr<<"here atom \n";
    (yyval.ptr) = new node("nt", "atom_expr");
    ast.add_edge((yyval.ptr), (yyvsp[-1].ptr));
    ast.add_edge((yyval.ptr), (yyvsp[0].ptr));
}
#line 2585 "parser.tab.cpp"
    break;

  case 122: /* atom_expr: atom trailer trailer  */
#line 662 "parser.y"
                         {  // Method calls inside object
    (yyval.ptr) = new node("nt", "atom_expr");
    ast.add_edge((yyval.ptr), (yyvsp[-2].ptr));
    ast.add_edge((yyval.ptr), (yyvsp[-1].ptr));
    ast.add_edge((yyval.ptr), (yyvsp[0].ptr));
}
#line 2596 "parser.tab.cpp"
    break;

  case 123: /* atom: '[' testlist ']'  */
#line 669 "parser.y"
                       {
    (yyval.ptr) = new node("nt", "atom");
    ast.add_node((yyval.ptr));
    ast.add_edge((yyval.ptr), (yyvsp[-2].ptr));
    ast.add_edge((yyval.ptr), (yyvsp[-1].ptr));
    ast.add_edge((yyval.ptr), (yyvsp[0].ptr));
}
#line 2608 "parser.tab.cpp"
    break;

  case 124: /* atom: '[' ']'  */
#line 675 "parser.y"
           {
    (yyval.ptr) = new node("nt", "atom");
    ast.add_node((yyval.ptr));
    ast.add_edge((yyval.ptr), (yyvsp[-1].ptr));
    ast.add_edge((yyval.ptr), (yyvsp[0].ptr));
}
#line 2619 "parser.tab.cpp"
    break;

  case 125: /* atom: '(' test ')'  */
#line 680 "parser.y"
                 {
    (yyval.ptr) = new node("nt", "atom");
    ast.add_edge((yyval.ptr), (yyvsp[-2].ptr));
    ast.add_edge((yyval.ptr), (yyvsp[-1].ptr));
    ast.add_edge((yyval.ptr), (yyvsp[0].ptr));
}
#line 2630 "parser.tab.cpp"
    break;

  case 126: /* atom: NAME  */
#line 685 "parser.y"
         {
    (yyval.ptr) = new node("nt", "atom");
    ast.add_edge((yyval.ptr), (yyvsp[0].ptr));
}
#line 2639 "parser.tab.cpp"
    break;

  case 127: /* atom: NUMBER  */
#line 688 "parser.y"
           {
    (yyval.ptr) = new node("nt", "atom");
    ast.add_edge((yyval.ptr), (yyvsp[0].ptr));
}
#line 2648 "parser.tab.cpp"
    break;

  case 128: /* atom: NONE  */
#line 691 "parser.y"
          {
    (yyval.ptr) = new node("nt", "atom");
    ast.add_edge((yyval.ptr), (yyvsp[0].ptr));
}
#line 2657 "parser.tab.cpp"
    break;

  case 129: /* atom: TRUE  */
#line 694 "parser.y"
         {
    (yyval.ptr) = new node("nt", "atom");
    ast.add_edge((yyval.ptr), (yyvsp[0].ptr));
}
#line 2666 "parser.tab.cpp"
    break;

  case 130: /* atom: FALSE  */
#line 697 "parser.y"
          {
    (yyval.ptr) = new node("nt", "atom");
    ast.add_edge((yyval.ptr), (yyvsp[0].ptr));
}
#line 2675 "parser.tab.cpp"
    break;

  case 131: /* atom: STRING  */
#line 700 "parser.y"
           {
    (yyval.ptr) = new node("nt", "atom");
    ast.add_edge((yyval.ptr), (yyvsp[0].ptr));
}
#line 2684 "parser.tab.cpp"
    break;

  case 132: /* testlist: test  */
#line 705 "parser.y"
              {
    (yyval.ptr) = new node("nt", "testlist");
    ast.add_edge((yyval.ptr), (yyvsp[0].ptr));
}
#line 2693 "parser.tab.cpp"
    break;

  case 133: /* testlist: testlist ',' test  */
#line 708 "parser.y"
                     {
    (yyval.ptr) = new node("nt", "testlist");
    ast.add_edge((yyval.ptr), (yyvsp[-2].ptr));
    ast.add_edge((yyval.ptr), (yyvsp[-1].ptr));
    ast.add_edge((yyval.ptr), (yyvsp[0].ptr));
}
#line 2704 "parser.tab.cpp"
    break;

  case 134: /* trailer: '(' cond_arglist ')'  */
#line 715 "parser.y"
                              {
    (yyval.ptr) = new node("nt", "trailer");
    ast.add_node((yyval.ptr));
    ast.add_edge((yyval.ptr), (yyvsp[-2].ptr));
    ast.add_edge((yyval.ptr), (yyvsp[-1].ptr));
    ast.add_edge((yyval.ptr), (yyvsp[0].ptr));
}
#line 2716 "parser.tab.cpp"
    break;

  case 135: /* trailer: '[' test ']'  */
#line 721 "parser.y"
                 {
    (yyval.ptr) = new node("nt", "trailer");
    ast.add_node((yyval.ptr));
    ast.add_edge((yyval.ptr), (yyvsp[-2].ptr));
    ast.add_edge((yyval.ptr), (yyvsp[-1].ptr));
    ast.add_edge((yyval.ptr), (yyvsp[0].ptr));
}
#line 2728 "parser.tab.cpp"
    break;

  case 136: /* trailer: '.' NAME  */
#line 727 "parser.y"
             {
    (yyval.ptr) = new node("nt", "trailer");
    ast.add_node((yyval.ptr));
    ast.add_edge((yyval.ptr), (yyvsp[-1].ptr));
    ast.add_edge((yyval.ptr), (yyvsp[0].ptr));

}
#line 2740 "parser.tab.cpp"
    break;

  case 137: /* classdef: CLASS NAME cond_parent_class ':' suite  */
#line 736 "parser.y"
                                                {
    (yyval.ptr) = new node("nt", "classdef");
    ast.add_edge((yyval.ptr), (yyvsp[-4].ptr));
    ast.add_edge((yyval.ptr), (yyvsp[-3].ptr));
    ast.add_edge((yyval.ptr), (yyvsp[-2].ptr));
    ast.add_edge((yyval.ptr), (yyvsp[-1].ptr));
    ast.add_edge((yyval.ptr), (yyvsp[0].ptr));
}
#line 2753 "parser.tab.cpp"
    break;

  case 138: /* cond_parent_class: '(' NAME ')'  */
#line 745 "parser.y"
                               {
    (yyval.ptr) = new node("nt", "cond_parent_class");
    ast.add_edge((yyval.ptr), (yyvsp[-2].ptr));
    ast.add_edge((yyval.ptr), (yyvsp[-1].ptr));
    ast.add_edge((yyval.ptr), (yyvsp[0].ptr));
}
#line 2764 "parser.tab.cpp"
    break;

  case 139: /* cond_parent_class: %empty  */
#line 750 "parser.y"
    {
    (yyval.ptr) = NULL;
}
#line 2772 "parser.tab.cpp"
    break;

  case 140: /* arglist: argument  */
#line 754 "parser.y"
                  {
    (yyval.ptr) = new node("nt", "arglist");
    ast.add_edge((yyval.ptr), (yyvsp[0].ptr));
}
#line 2781 "parser.tab.cpp"
    break;

  case 141: /* arglist: arglist ',' argument  */
#line 757 "parser.y"
                         { 
    (yyval.ptr) = new node("nt", "arglist");
    ast.add_node((yyval.ptr));
    ast.add_edge((yyval.ptr), (yyvsp[-2].ptr));
    ast.add_edge((yyval.ptr), (yyvsp[-1].ptr));
    ast.add_edge((yyval.ptr), (yyvsp[0].ptr));
}
#line 2793 "parser.tab.cpp"
    break;

  case 142: /* argument: test  */
#line 775 "parser.y"
               {
        (yyval.ptr) = new node("nt", "argument");
        ast.add_edge((yyval.ptr), (yyvsp[0].ptr));
    }
#line 2802 "parser.tab.cpp"
    break;


#line 2806 "parser.tab.cpp"

      default: break;
    }
  /* User semantic actions sometimes alter yychar, and that requires
     that yytoken be updated with the new translation.  We take the
     approach of translating immediately before every use of yytoken.
     One alternative is translating here after every semantic action,
     but that translation would be missed if the semantic action invokes
     YYABORT, YYACCEPT, or YYERROR immediately after altering yychar or
     if it invokes YYBACKUP.  In the case of YYABORT or YYACCEPT, an
     incorrect destructor might then be invoked immediately.  In the
     case of YYERROR or YYBACKUP, subsequent parser actions might lead
     to an incorrect destructor call or verbose syntax error message
     before the lookahead is translated.  */
  YY_SYMBOL_PRINT ("-> $$ =", YY_CAST (yysymbol_kind_t, yyr1[yyn]), &yyval, &yyloc);

  YYPOPSTACK (yylen);
  yylen = 0;

  *++yyvsp = yyval;

  /* Now 'shift' the result of the reduction.  Determine what state
     that goes to, based on the state we popped back to and the rule
     number reduced by.  */
  {
    const int yylhs = yyr1[yyn] - YYNTOKENS;
    const int yyi = yypgoto[yylhs] + *yyssp;
    yystate = (0 <= yyi && yyi <= YYLAST && yycheck[yyi] == *yyssp
               ? yytable[yyi]
               : yydefgoto[yylhs]);
  }

  goto yynewstate;


/*--------------------------------------.
| yyerrlab -- here on detecting error.  |
`--------------------------------------*/
yyerrlab:
  /* Make sure we have latest lookahead translation.  See comments at
     user semantic actions for why this is necessary.  */
  yytoken = yychar == YYEMPTY ? YYSYMBOL_YYEMPTY : YYTRANSLATE (yychar);
  /* If not already recovering from an error, report this error.  */
  if (!yyerrstatus)
    {
      ++yynerrs;
      yyerror (YY_("syntax error"));
    }

  if (yyerrstatus == 3)
    {
      /* If just tried and failed to reuse lookahead token after an
         error, discard it.  */

      if (yychar <= YYEOF)
        {
          /* Return failure if at end of input.  */
          if (yychar == YYEOF)
            YYABORT;
        }
      else
        {
          yydestruct ("Error: discarding",
                      yytoken, &yylval);
          yychar = YYEMPTY;
        }
    }

  /* Else will try to reuse lookahead token after shifting the error
     token.  */
  goto yyerrlab1;


/*---------------------------------------------------.
| yyerrorlab -- error raised explicitly by YYERROR.  |
`---------------------------------------------------*/
yyerrorlab:
  /* Pacify compilers when the user code never invokes YYERROR and the
     label yyerrorlab therefore never appears in user code.  */
  if (0)
    YYERROR;
  ++yynerrs;

  /* Do not reclaim the symbols of the rule whose action triggered
     this YYERROR.  */
  YYPOPSTACK (yylen);
  yylen = 0;
  YY_STACK_PRINT (yyss, yyssp);
  yystate = *yyssp;
  goto yyerrlab1;


/*-------------------------------------------------------------.
| yyerrlab1 -- common code for both syntax error and YYERROR.  |
`-------------------------------------------------------------*/
yyerrlab1:
  yyerrstatus = 3;      /* Each real token shifted decrements this.  */

  /* Pop stack until we find a state that shifts the error token.  */
  for (;;)
    {
      yyn = yypact[yystate];
      if (!yypact_value_is_default (yyn))
        {
          yyn += YYSYMBOL_YYerror;
          if (0 <= yyn && yyn <= YYLAST && yycheck[yyn] == YYSYMBOL_YYerror)
            {
              yyn = yytable[yyn];
              if (0 < yyn)
                break;
            }
        }

      /* Pop the current state because it cannot handle the error token.  */
      if (yyssp == yyss)
        YYABORT;


      yydestruct ("Error: popping",
                  YY_ACCESSING_SYMBOL (yystate), yyvsp);
      YYPOPSTACK (1);
      yystate = *yyssp;
      YY_STACK_PRINT (yyss, yyssp);
    }

  YY_IGNORE_MAYBE_UNINITIALIZED_BEGIN
  *++yyvsp = yylval;
  YY_IGNORE_MAYBE_UNINITIALIZED_END


  /* Shift the error token.  */
  YY_SYMBOL_PRINT ("Shifting", YY_ACCESSING_SYMBOL (yyn), yyvsp, yylsp);

  yystate = yyn;
  goto yynewstate;


/*-------------------------------------.
| yyacceptlab -- YYACCEPT comes here.  |
`-------------------------------------*/
yyacceptlab:
  yyresult = 0;
  goto yyreturnlab;


/*-----------------------------------.
| yyabortlab -- YYABORT comes here.  |
`-----------------------------------*/
yyabortlab:
  yyresult = 1;
  goto yyreturnlab;


/*-----------------------------------------------------------.
| yyexhaustedlab -- YYNOMEM (memory exhaustion) comes here.  |
`-----------------------------------------------------------*/
yyexhaustedlab:
  yyerror (YY_("memory exhausted"));
  yyresult = 2;
  goto yyreturnlab;


/*----------------------------------------------------------.
| yyreturnlab -- parsing is finished, clean up and return.  |
`----------------------------------------------------------*/
yyreturnlab:
  if (yychar != YYEMPTY)
    {
      /* Make sure we have latest lookahead translation.  See comments at
         user semantic actions for why this is necessary.  */
      yytoken = YYTRANSLATE (yychar);
      yydestruct ("Cleanup: discarding lookahead",
                  yytoken, &yylval);
    }
  /* Do not reclaim the symbols of the rule whose action triggered
     this YYABORT or YYACCEPT.  */
  YYPOPSTACK (yylen);
  YY_STACK_PRINT (yyss, yyssp);
  while (yyssp != yyss)
    {
      yydestruct ("Cleanup: popping",
                  YY_ACCESSING_SYMBOL (+*yyssp), yyvsp);
      YYPOPSTACK (1);
    }
#ifndef yyoverflow
  if (yyss != yyssa)
    YYSTACK_FREE (yyss);
#endif

  return yyresult;
}

#line 780 "parser.y"



void print_symbol_table(symbol_table *curr_table){

    string name = "";
    if(curr_table->type==GLOBAL_TABLE){
        name = "../symbol_tables/GLOBAL_TABLE.csv";
    }
    else if(curr_table->type==FUNCTION_TABLE){
        name = "../symbol_tables/FUNCTION_TABLE_" + curr_table->name + ".csv";
    }
    else{
        name = "../symbol_tables/CLASS_TABLE_" + curr_table->name + ".csv";
    }
    ofstream fout(name);

    fout<<"VARIABLES:\n";
    fout<<"Name,Line number,Size,Offset\n";
    for(auto p: curr_table->var_defs){
        auto x = p.first;
        auto entry = p.second;
        fout<<entry->name<<","<<entry->lineno<<","<<entry->size<<","<<entry->offset<<"\n";
    }
    fout<<"FUNCTIONS:\n";
    for(auto p: curr_table->fun_defs){
        auto x = p.first;
        auto table = p.second;
        fout<<x<<","<<table->lineno<<","<<table->size<<"\n";
        print_symbol_table(table);
    }
    fout<<"CLASSES:\n";
    for(auto p: curr_table->class_defs){
        auto x = p.first;
        auto table = p.second;
        fout<<x<<","<<table->lineno<<","<<table->size<<"\n";
        print_symbol_table(table);
    }
}

vector<string> x86data = {"int_fmt:\n\t.string \"%ld\\n\"\n\n"s};
vector<string> x86;

string printutil(void* v, string s, ofstream &fout, int type){
    string res = "";
    int ofst = 0;
    if(type == TEMP_VAR || type == TEMP_VAR_ARG){
        ofst = ((temp_var*)v)->offset;
        /* cerr<<s<<" "<<ofst<<"\n"; */
        res.append("-"s + to_string(ofst));
        res.append("(%rbp)");
    }
    else if(type == NUM){
        res.append("$"s + s);
    }
    else if(type == STR){
        res.append(s);
    }
    else if(type == VAR){
        auto it = (symbol_table_entry*)v;
        if(it->stackofst > 0){
            ofst = it->stackofst;
            /* cerr<<s<<" "<<ofst<<"\n"; */
            res.append(to_string(ofst));
            res.append("(%rbp)");
        }
        else{
            ofst = it->offset;
            /* cerr<<s<<" "<<ofst<<"\n"; */
            res.append("-"s + to_string(ofst));
            res.append("(%rbp)");
        }
    }
    else if(type == ARR_ACCESS){
        auto arr = (arr_access*)(v);
        auto entry = arr->en;
        string z = "";
        if(arr->tempidx){
            z = printutil(arr->accessind, arr->name, fout, TEMP_VAR);
            /* cout<<"heyyy "<<z<<"\n"; */
        }
        else{
            /* cerr<<"yo\n"; */
            z = printutil(NULL, to_string(arr->offset), fout, NUM);
            /* cout<<"hey "<<z<<"\n"; */
        }
        /* if(entry==NULL)     cerr<<"yes\n"; */
        x86.push_back("\tmovq " + z + ", %r9\n");
        if(entry->stackofst > 0){
            x86.push_back("\tmovq " + to_string(entry->stackofst) + "(%rbp), %r10\n");
        }
        else{
            x86.push_back("\tmovq -" + to_string(entry->offset) + "(%rbp), %r10\n");
        }
        res = "(%r9, %r10)";
    }
    else if(type==OBJ_ACCESS){
        auto obj = (obj_access*)v;
        string z;
        auto entry = obj->en;
        z = printutil(NULL, to_string(obj->offset), fout, NUM);
        x86.push_back("\tmovq " + z + ", %r9\n");
        if(entry->stackofst > 0){
            cout<<"yes\n";
            x86.push_back("\tmovq " + to_string(entry->stackofst) + "(%rbp), %r10\n");
        }
        else{
            x86.push_back("\tmovq -" + to_string(entry->offset) + "(%rbp), %r10\n");
        }
        res = "(%r9, %r10)";
    }
    else if(type==ARG){
        ofst = ((symbol_table_entry*)v)->stackofst;
        /* cerr<<s<<" "<<ofst<<"\n"; */
        res.append(to_string(ofst));
        res.append("(%rbp)");
    }
    /* else if(type==OBJ_FUNC) */
    return res;
}


void printx86(vector<quad> code){
    ofstream z("x86.s");
    ofstream fout("x86.s", ios::app);

    fout<<".section .data\n\n";
    fout<<".text\n";

    /* for(int i=0; i<25; i++){ */
    for(auto x: code){
        /* auto x = code[i];  */
        x86.push_back("# -------->\t" + x.result + "\t=\t" + x.arg1 + "\t" + x.op + "\t" + x.arg2 + "\n");
        /* cerr<<x86.back()<<"\n"; */
        if(x.op=="label"){
            if(x.arg1 == "beginfunc main"){
                x86.push_back(".globl main\n");
                x86.push_back(".type main, @function\n");
                x86.push_back("main:\n");
                if(((symbol_table*)(x.a1))->offset % 16 == 8){
                    ((symbol_table*)(x.a1))->offset += 8;
                }
                x86.push_back("\tpushq %rbp\n\tmovq %rsp, %rbp\n");
                x86.push_back("\tsubq $" + to_string(((symbol_table*)(x.a1))->offset) + ", %rsp\n");
            }
            else if(x.arg1.substr(0, 9)=="beginfunc"){
                x86.push_back(x.arg1.substr(10, x.arg1.size()-10) + ":\n");
                if(((symbol_table*)(x.a1))->offset % 16 == 8){
                    ((symbol_table*)(x.a1))->offset += 8;
                }
                x86.push_back("\tpushq %rbp\n\tmovq %rsp, %rbp\n");
                x86.push_back("\tsubq $" + to_string(((symbol_table*)(x.a1))->offset) + ", %rsp\n");
            }
            else if(x.arg1.substr(0, 7)=="endfunc"){
                x86.push_back("\n" + x.arg1 + ":\n");
                x86.push_back("\n\tleave\n\tret\n\n");
            }
            else{
                x86.push_back("\n" + x.arg1 + ":\n");
            }
        }
        else if(x.op=="param"){
            if(x.typeres==NUM){
                string sres = printutil(x.res, x.result, fout, x.typeres);
                x86.push_back("\tmovq " + sres + ", %rdi\n");
            }
            else if(x.typeres==TEMP_VAR_ARG){
                string sres = printutil(x.res, x.result, fout, x.typeres);
                x86.push_back("\tpushq " + sres + "\n");
            }
            else if(x.typeres==TEMP_VAR){
                string sres = printutil(x.res, x.result, fout, x.typeres);
                x86.push_back("\tmovq " + sres + ", %rdi\n");
            }
            /* else if(x.typeres==OBJ_FUNC){
                string sres = printutil(, fout, x.typeres)
            } */
        }
        else if(x.op=="return"){
            if(x.arg2==""){
                x86.push_back("\tleave\n\tret\n\n");
            }
            else{
                string sa2 = printutil(x.a2, x.arg2, fout, x.typea2);
                x86.push_back("\tmovq " + sa2 + ", %rax\n");
            }
        }
        else if(x.op=="popreturn"){
            string sres = printutil(x.res, x.result, fout, x.typeres);
            x86.push_back("\tmovq %rax, " + sres + "\n");
        }
        else if(x.op=="popparam"){
            printutil(x.res, x.result, fout, x.typeres);
        }
        else if(x.op=="callfunc "|| x.op=="callfunc"){
            if(x.arg1 == "print"){
                auto z = (temp_var*)x.res;
                /* cerr<<"heyyy "<<z->type<<"\n"; */
                if(z->type != "str"){
                    x86.push_back("\tmovq %rdi, %rsi\n");
                    x86.push_back("\tmovq $int_fmt, %rdi\n");
                    x86.push_back("\txorq %rax, %rax\n");
                    x86.push_back("\tcall printf\n");
                }
                else{
                    x86.push_back("\txorq %rax, %rax\n");
                    x86.push_back("\tcall printf\n");
                }
            }
            else if(x.arg1 == "allocmem 1" || x.arg1 == "allocmem"){
                x86.push_back("\tcall malloc\n");
                /* x86.push_back("\tmovq %rax, %rbx\n"); */
            }
            else{
                string sa1 = printutil(x.a1, x.arg1, fout, x.typea1);
                x86.push_back("\tcall " + sa1 +"\n");
                x86.push_back("\taddq $" + to_string(stoi(x.arg2)*8) + ", %rsp\n");
            }
        }

        else if(x.op=="goto" && x.arg1==""){
            x86.push_back("\tjmp " + x.result + "\n");
        }
        else if(x.op=="goto"){
            string sa2 = printutil(x.a2, x.arg2, fout, x.typea2);
            x86.push_back("\tmovq " + sa2 +", %rax\n");
            x86.push_back("\tcmpq $0, %rax\n");
            x86.push_back("\tje " + x.result +"\n");
        }
        else if(x.op=="+"){
            /* cerr<<"here +\n"; */
            string sa1 = printutil(x.a1, x.arg1, fout, x.typea1);
            string sa2 = printutil(x.a2, x.arg2, fout, x.typea2);
            string sres = printutil(x.res, x.result, fout, x.typeres);
            x86.push_back("\tmovq " + sa1 + ", %rax\n");
            x86.push_back("\taddq " + sa2 + ", %rax\n");
            x86.push_back("\tmovq %rax, " + sres + "\n");
        }
        else if(x.op=="-"){
            /* cerr<<"here -\n"; */
            string sa1 = "$0";
            if(x.arg1!="")  sa1 = printutil(x.a1, x.arg1, fout, x.typea1);
            string sa2 = printutil(x.a2, x.arg2, fout, x.typea2);
            string sres = printutil(x.res, x.result, fout, x.typeres);
            x86.push_back("\tmovq " + sa1 + ", %rax\n");
            x86.push_back("\tsubq " + sa2 + ", %rax\n");
            x86.push_back("\tmovq %rax, " + sres + "\n");
        }
        else if(x.op=="*"){
            /* cerr<<"here *\n"; */
            string sa1 = printutil(x.a1, x.arg1, fout, x.typea1);
            string sa2 = printutil(x.a2, x.arg2, fout, x.typea2);
            string sres = printutil(x.res, x.result, fout, x.typeres);
            x86.push_back("\tmovq " + sa1 + ", %rax\n");
            x86.push_back("\timulq " + sa2 + ", %rax\n");
            x86.push_back("\tmovq %rax, " + sres + "\n");
        }
        else if(x.op=="/" || x.op=="//"){
            /* cerr<<"here /\n"; */
            string sa1 = printutil(x.a1, x.arg1, fout, x.typea1);
            string sa2 = printutil(x.a2, x.arg2, fout, x.typea2);
            string sres = printutil(x.res, x.result, fout, x.typeres);
            x86.push_back("\txorq %rdx, %rdx\n");
            x86.push_back("\tmovq " + sa1 + ", %rax\n");
            x86.push_back("\tmovq " + sa2 + ", %rbx\n");
            x86.push_back("\tidivq %rbx\n");
            x86.push_back("\tmovq %rax, " + sres + "\n");
        }
        else if(x.op=="|"){
            /* cerr<<"here |\n"; */
            string sa1 = printutil(x.a1, x.arg1, fout, x.typea1);
            string sa2 = printutil(x.a2, x.arg2, fout, x.typea2);
            string sres = printutil(x.res, x.result, fout, x.typeres);
            x86.push_back("\tmovq " + sa1 + ", %rax\n");
            x86.push_back("\torq " + sa2 + ", %rax\n");
            x86.push_back("\tmovq %rax, " + sres + "\n");
        }
        else if(x.op=="&"){
            /* cerr<<"here &\n"; */
            string sa1 = printutil(x.a1, x.arg1, fout, x.typea1);
            string sa2 = printutil(x.a2, x.arg2, fout, x.typea2);
            string sres = printutil(x.res, x.result, fout, x.typeres);
            x86.push_back("\tmovq " + sa1 + ", %rax\n");
            x86.push_back("\tandq " + sa2 + ", %rax\n");
            x86.push_back("\tmovq %rax, " + sres + "\n");
        }
        else if(x.op=="<<"){
            /* cerr<<"here <<\n"; */
            string sa1 = printutil(x.a1, x.arg1, fout, x.typea1);
            string sa2 = printutil(x.a2, x.arg2, fout, x.typea2);
            string sres = printutil(x.res, x.result, fout, x.typeres);
            x86.push_back("\tmovq " + sa1 + ", %rax\n");
            x86.push_back("\tmovb " + sa2 + ", %cl\n");
            x86.push_back("\tshlq %cl, %rax\n");
            x86.push_back("\tmovq %rax, " + sres + "\n");
        }
        else if(x.op==">>"){
            /* cerr<<"here >>\n"; */
            string sa1 = printutil(x.a1, x.arg1, fout, x.typea1);
            string sa2 = printutil(x.a2, x.arg2, fout, x.typea2);
            string sres = printutil(x.res, x.result, fout, x.typeres);
            x86.push_back("\tmovq " + sa1 + ", %rax\n");
            x86.push_back("\tmovb " + sa2 + ", %cl\n");
            x86.push_back("\tshrq %cl, %rax\n");
            x86.push_back("\tmovq %rax, " + sres + "\n");
        }
        else if(x.op=="%"){
            /* cerr<<"here %\n"; */
            string sa1 = printutil(x.a1, x.arg1, fout, x.typea1);
            string sa2 = printutil(x.a2, x.arg2, fout, x.typea2);
            string sres = printutil(x.res, x.result, fout, x.typeres);
            x86.push_back("\txorq %rdx, %rdx\n");
            x86.push_back("\tmovq " + sa1 + ", %rax\n");
            x86.push_back("\tmovq " + sa2 + ", %rbx\n");
            x86.push_back("\tidivq %rbx\n");
            x86.push_back("\tmovq %rdx, " + sres + "\n");
        }
        else if(x.op=="=="){
            /* cerr<<"here ==\n"; */
            string sa1 = printutil(x.a1, x.arg1, fout, x.typea1);
            string sa2 = printutil(x.a2, x.arg2, fout, x.typea2);
            string sres = printutil(x.res, x.result, fout, x.typeres);
            x86.push_back("\tmovq " + sa1 + ", %rax\n");
            x86.push_back("\tcmpq " + sa2 + ", %rax\n");
            x86.push_back("\tsete %al\n");
            x86.push_back("\tmovzbq %al, %rax\n");
            x86.push_back("\tmovq %rax, " + sres + "\n");
        }
        else if(x.op=="!="){
            /* cerr<<"here !=\n"; */
            string sa1 = printutil(x.a1, x.arg1, fout, x.typea1);
            string sa2 = printutil(x.a2, x.arg2, fout, x.typea2);
            string sres = printutil(x.res, x.result, fout, x.typeres);
            x86.push_back("\tmovq " + sa1 + ", %rax\n");
            x86.push_back("\tcmpq " + sa2 + ", %rax\n");
            x86.push_back("\tsetne %al\n");
            x86.push_back("\tmovzbq %al, %rax\n");
            x86.push_back("\tmovq %rax, " + sres + "\n");
        }
        else if(x.op=="<="){
            /* cerr<<"here <=\n"; */
            string sa1 = printutil(x.a1, x.arg1, fout, x.typea1);
            string sa2 = printutil(x.a2, x.arg2, fout, x.typea2);
            string sres = printutil(x.res, x.result, fout, x.typeres);
            x86.push_back("\tmovq " + sa1 + ", %rax\n");
            x86.push_back("\tcmpq " + sa2 + ", %rax\n");
            x86.push_back("\tsetle %al\n");
            x86.push_back("\tmovzbq %al, %rax\n");
            x86.push_back("\tmovq %rax, " + sres + "\n");
        }
        else if(x.op==">="){
            /* cerr<<"here >=\n"; */
            string sa1 = printutil(x.a1, x.arg1, fout, x.typea1);
            string sa2 = printutil(x.a2, x.arg2, fout, x.typea2);
            string sres = printutil(x.res, x.result, fout, x.typeres);
            x86.push_back("\tmovq " + sa1 + ", %rax\n");
            x86.push_back("\tcmpq " + sa2 + ", %rax\n");
            x86.push_back("\tsetge %al\n");
            x86.push_back("\tmovzbq %al, %rax\n");
            x86.push_back("\tmovq %rax, " + sres + "\n");
        }
        else if(x.op=="<"){
            /* cerr<<"here <\n"; */
            string sa1 = printutil(x.a1, x.arg1, fout, x.typea1);
            string sa2 = printutil(x.a2, x.arg2, fout, x.typea2);
            string sres = printutil(x.res, x.result, fout, x.typeres);
            x86.push_back("\tmovq " + sa1 + ", %rax\n");
            x86.push_back("\tcmpq " + sa2 + ", %rax\n");
            x86.push_back("\tsetl %al\n");
            x86.push_back("\tmovzbq %al, %rax\n");
            x86.push_back("\tmovq %rax, " + sres + "\n");
        }
        else if(x.op==">"){
            /* cerr<<"here >\n"; */
            string sa1 = printutil(x.a1, x.arg1, fout, x.typea1);
            string sa2 = printutil(x.a2, x.arg2, fout, x.typea2);
            string sres = printutil(x.res, x.result, fout, x.typeres);
            x86.push_back("\tmovq " + sa1 + ", %rax\n");
            x86.push_back("\tcmpq " + sa2 + ", %rax\n");
            x86.push_back("\tsetg %al\n");
            x86.push_back("\tmovzbq %al, %rax\n");
            x86.push_back("\tmovq %rax, " + sres + "\n");
        }
        else if(x.op==""){
            if(x.typea1==STR){
                string z = x.arg1.substr(1, size(x.arg1)-1) + ":\n\t.string\t" + x.arg2 + "\n\n";
                x86data.push_back(z);
            }
            string sa1 = printutil(x.a1, x.arg1, fout, x.typea1);
            string sres = printutil(x.res, x.result, fout, x.typeres);
            x86.push_back("\tmovq " + sa1 + ", %rax" + "\n");
            x86.push_back("\tmovq %rax, " + sres + "\n");
        }
        else{
            /* cerr<<x.op<<"   yoyoyoyo\n"; */
        }
    }

    for(auto x: x86data)    fout<<x;
    for(auto x: x86)    fout<<x;

}


int main(int argc, char *argv[]){
    /* yydebug = 1  */
    if(argc > 1){

    }
    else{
        cerr << "No Input file specified.\nParsing Terminated\n";
        return -1;
    }
    present_table = new symbol_table(SYMBOL_TABLE_TYPE::GLOBAL_TABLE, NULL);
    symbol_table_entry * nameEntry = new symbol_table_entry("__name__", "str", present_table);
    present_table->add_entry_var(nameEntry);
    /* symbol_table * rangef = new symbol_table(FUNCTION_TABLE, present_table, "range");
    present_table->add_entry_fun(rangef); */
    yyin = fopen(argv[1], "r");
    if(yyin == NULL){
        cerr << "Failed to open input file.\n Terminated\n";
        return -1;
    }
    indents.push(0);
    if(!yyparse()) cerr << "Parsing successful\n";
    else return -1;
    make_3ac(root);
    /* cerr << root->code.size() << '\n'; */
    /* for(auto x: headers) cout << x << '\n'; */

    ofstream z("3ac.txt");
    ofstream fout("3ac.txt", ios::app);
    for(auto x: root->code){
        /* cerr << x.result << " = " << x.arg1 << ' ' << x.op << ' ' << x.arg2 << '\n'; */
        if(x.op=="label"){
            fout<<"\n"<<x.arg1<<":\n";
        }
        else if(x.op=="param"){
            fout<<setw(4)<<left<<"";
            fout<<"param "<<x.result<<"\n";
        }
        else if(x.op=="popparam" || x.op=="popreturn"){
            fout<<setw(4)<<left<<"";
            fout<<setw(12)<<left<<x.result<<" ";
            fout<<setw(4)<<left<<"=";
            fout<<setw(4)<<left<<x.op<<" ";
            fout<<"\n";
        }
        else if(x.op=="callfunc "|| x.op=="callfunc"){
            fout<<setw(4)<<left<<"";
            fout<<"callfunc ";
            fout<<setw(12)<<x.arg1<<" ";
            fout<<setw(12)<<x.arg2<<" ";
            fout<<"\n";
        }
        else if(x.op=="goto" && x.arg1==""){
            fout<<setw(4)<<left<<"";
            fout<<"goto "<<x.result<<"\n";
        }
        else if(x.op=="goto"){
            fout<<setw(4)<<left<<"";
            fout<<setw(12)<<x.arg1<<" ";
            fout<<setw(12)<<x.arg2<<" ";
            fout<<"goto "<<x.result<<"\n";
        }
        else{
            fout<<setw(4)<<left<<"";
            fout<<setw(12)<<left<<x.result<<" ";
            fout<<setw(4)<<left<<"=";
            fout<<setw(12)<<left<<x.arg1<<" ";
            fout<<setw(4)<<left<<x.op<<" ";
            fout<<setw(12)<<left<<x.arg2<<" ";
            fout<<"\n";
        }
    }

    /* print_symbol_table(present_table); */
    printx86(root->code);

    return 0;
}
