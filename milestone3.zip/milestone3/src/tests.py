def main() -> None:
    a: str = 'hello'
    print("Hello, World!")

if __name__ == "__main__":
    main()
