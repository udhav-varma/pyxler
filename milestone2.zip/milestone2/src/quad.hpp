#include<bits/stdc++.h>
using std::string;
class quad{
public:
    string arg1;
    string arg2;
    string op;
    string result;
    quad(string arg1, string arg2, string op, string result);
};

