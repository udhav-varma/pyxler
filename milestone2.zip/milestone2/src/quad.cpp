#include "quad.hpp"

quad::quad(string arg1, string arg2, string op, string result)
{
    this->arg1 = arg1;
    this->arg2 = arg2;
    this->op = op;
    this->result = result;
}